namespace sap.capire.salesorder;


using { Currency, managed, cuid } from '@sap/cds/common';


entity ShipmentTracking : managed {
  key trackingNumber : String(30);
  carrier            : String(20);      // DHL, FEDEX, etc.
  deliveryStatus     : String(20);      // in_transit, delivered
  deliveryDate       : DateTime;
  deliveryLocation   : String(200);
  lastStatus         : String(500);
  lastUpdatedAt      : Timestamp;
  isActive           : Boolean default true;  // false when delivered
  poNumber           : String(50);      // Reference to original PO
  description        : String(500);     // Item description
}

