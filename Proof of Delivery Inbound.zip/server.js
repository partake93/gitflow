// Load environment variables from .env file
require("dotenv").config();

const cds = require("@sap/cds");

cds.on("bootstrap", (app) => {
  // Register custom file upload handler
  require("./srv/upload-handler")(app);
});

// Load scheduled jobs
cds.on("served", () => {
  console.log("🚀 Loading scheduled jobs...");
  require("./srv/scheduled-jobs");
});

module.exports = cds.server;
