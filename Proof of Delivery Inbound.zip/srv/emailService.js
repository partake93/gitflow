const cds = require("@sap/cds");

/**
 * Service to fetch emails from Microsoft Graph API using SAP BTP Destination
 */
module.exports = async function () {
  // Connect to the MS Graph API destination configured in SAP BTP
  const msGraphAPI = await cds.connect.to("GRAPH");

  this.on("getEmailsFromDestination", async (req) => {
    const startTime = Date.now();
    console.log("[getEmailsFromDestination] Request received", {
      timestamp: new Date().toISOString(),
      data: req.data,
    });

    try {
      const { userEmail, folderId, maxMessages } = req.data;

      // Set default values
      const folder = folderId || "inbox";
      const top = maxMessages || 10;
      const emailAddress = userEmail || "me";

      console.log("[getEmailsFromDestination] Processing request", {
        userEmail: emailAddress,
        folder: folder,
        maxMessages: top,
        defaults: {
          userEmail: !userEmail ? "me (default)" : "provided",
          folder: !folderId ? "inbox (default)" : "provided",
          maxMessages: !maxMessages ? "10 (default)" : "provided",
        },
      });

      // Construct the Microsoft Graph API endpoint
      const endpoint = `/users/${emailAddress}/mailFolders/${folder}/messages`;

      // Build query string manually
      const queryString = `$top=${top}&$select=id,subject,from,receivedDateTime,bodyPreview,hasAttachments,isRead&$orderby=receivedDateTime desc`;

      console.log("[getEmailsFromDestination] Calling MS Graph API", {
        endpoint: endpoint,
        queryString: queryString,
      });

      // Make request to MS Graph API through the destination
      const response = await msGraphAPI.send({
        method: "GET",
        path: `${endpoint}?${queryString}`,
      });

      const duration = Date.now() - startTime;
      console.log("[getEmailsFromDestination] Successfully fetched emails", {
        count: response.value?.length || 0,
        duration: `${duration}ms`,
        timestamp: new Date().toISOString(),
      });

      return {
        success: true,
        count: response.value?.length || 0,
        emails: response.value || [],
        message: "Emails fetched successfully",
      };
    } catch (error) {
      const duration = Date.now() - startTime;
      console.error("[getEmailsFromDestination] Error occurred", {
        error: error.message,
        stack: error.stack,
        duration: `${duration}ms`,
        timestamp: new Date().toISOString(),
      });
      req.error(500, `Failed to fetch emails: ${error.message}`);
    }
  });

  this.on("getEmailDetailsFromDestination", async (req) => {
    try {
      const { userEmail, emailId } = req.data;

      if (!emailId) {
        req.error(400, "Email ID is required");
        return;
      }

      const emailAddress = userEmail || "me";

      console.log(`Fetching email details for ID: ${emailId}`);

      // Get email details
      const endpoint = `/users/${emailAddress}/messages/${emailId}`;
      const queryString = `$select=id,subject,from,toRecipients,ccRecipients,receivedDateTime,sentDateTime,body,bodyPreview,hasAttachments,isRead,importance,categories`;

      const response = await msGraphAPI.send({
        method: "GET",
        path: `${endpoint}?${queryString}`,
      });

      console.log(`Successfully fetched email: ${response.subject}`);

      return {
        success: true,
        email: response,
        message: "Email details fetched successfully",
      };
    } catch (error) {
      console.error("Error fetching email details:", error.message);
      req.error(500, `Failed to fetch email details: ${error.message}`);
    }
  });

  this.on("getEmailAttachmentsFromDestination", async (req) => {
    try {
      const { userEmail, emailId } = req.data;

      if (!emailId) {
        req.error(400, "Email ID is required");
        return;
      }

      const emailAddress = userEmail || "me";

      console.log(`Fetching attachments for email ID: ${emailId}`);

      // Get attachments
      const endpoint = `/users/${emailAddress}/messages/${emailId}/attachments`;
      const queryString = `$select=id,name,contentType,size,isInline`;

      const response = await msGraphAPI.send({
        method: "GET",
        path: `${endpoint}?${queryString}`,
      });

      console.log(
        `Successfully fetched ${response.value?.length || 0} attachments`,
      );

      return {
        success: true,
        count: response.value?.length || 0,
        attachments: response.value || [],
        message: "Attachments fetched successfully",
      };
    } catch (error) {
      console.error("Error fetching attachments:", error.message);
      req.error(500, `Failed to fetch attachments: ${error.message}`);
    }
  });

  this.on("downloadAttachmentFromDestination", async (req) => {
    try {
      const { userEmail, emailId, attachmentId } = req.data;

      if (!emailId || !attachmentId) {
        req.error(400, "Email ID and Attachment ID are required");
        return;
      }

      const emailAddress = userEmail || "me";

      console.log(
        `Downloading attachment ${attachmentId} from email ${emailId}`,
      );

      // Get specific attachment with content
      const endpoint = `/users/${emailAddress}/messages/${emailId}/attachments/${attachmentId}`;

      const response = await msGraphAPI.send({
        method: "GET",
        path: endpoint,
      });

      console.log(`Successfully downloaded attachment: ${response.name}`);

      return {
        success: true,
        attachment: {
          id: response.id,
          name: response.name,
          contentType: response.contentType,
          size: response.size,
          contentBytes: response.contentBytes,
        },
        message: "Attachment downloaded successfully",
      };
    } catch (error) {
      console.error("Error downloading attachment:", error.message);
      req.error(500, `Failed to download attachment: ${error.message}`);
    }
  });

  this.on("searchEmailsFromDestination", async (req) => {
    try {
      const { userEmail, searchQuery, maxResults } = req.data;

      if (!searchQuery) {
        req.error(400, "Search query is required");
        return;
      }

      const emailAddress = userEmail || "me";
      const top = maxResults || 10;

      console.log(`Searching emails with query: ${searchQuery}`);

      // Search emails
      const endpoint = `/users/${emailAddress}/messages`;
      const queryString = `$top=${top}&$search="${searchQuery}"&$select=id,subject,from,receivedDateTime,bodyPreview,hasAttachments,isRead&$orderby=receivedDateTime desc`;

      const response = await msGraphAPI.send({
        method: "GET",
        path: `${endpoint}?${queryString}`,
      });

      console.log(`Search returned ${response.value?.length || 0} results`);

      return {
        success: true,
        count: response.value?.length || 0,
        emails: response.value || [],
        message: "Email search completed successfully",
      };
    } catch (error) {
      console.error("Error searching emails:", error.message);
      req.error(500, `Failed to search emails: ${error.message}`);
    }
  });
};
