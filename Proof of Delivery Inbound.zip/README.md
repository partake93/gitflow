# Inbound Delivery Date Management Application

This is an enterprise-grade SAP Cloud Application Programming Model (CAP) project for automated inbound delivery date management with AI-powered document processing, shipment tracking, and Microsoft 365 integration.

## Project Overview

An intelligent delivery management system that automates the entire process from purchase order document receipt to delivery tracking and reporting. The application leverages AI for document extraction, integrates with logistics carriers for real-time tracking, and seamlessly connects with Microsoft 365 services.

### Key Features

✅ **AI-Powered Document Processing**

- PDF and image document analysis using SAP AI Core
- Automatic extraction of PO numbers, materials, delivery dates, and tracking information
- Support for multiple AI models (GPT-4o, GPT-5-nano)
- Intelligent JSON repair and data normalization

✅ **Email Integration**

- Microsoft Outlook integration via Microsoft Graph API
- Automatic email retrieval and attachment processing
- Search and filter capabilities
- Support for both direct Graph API and SAP BTP Destination Service

✅ **SharePoint Integration**

- File upload/download from SharePoint document libraries
- Automatic upload of tracking reports to SharePoint
- List and browse SharePoint files
- Secure authentication via Microsoft Graph API

✅ **Unified Shipment Tracking**

- Real-time tracking for DHL and FedEx shipments
- Auto-detection of carrier from document data
- Batch tracking for multiple shipments
- Scheduled automatic tracking refresh
- Persistent tracking data storage

✅ **Excel Export & Reporting**

- Automatic Excel report generation for shipment tracking
- Formatted tracking event timelines
- Auto-upload to SharePoint (optional)
- Local file storage in `files/exports/`

✅ **Workflow Integration**

- SAP Build Process Automation integration
- Automated notifications for delivery status changes
- Webhook support for external systems

✅ **SAP BTP Ready**

- Full Multi-Target Application (MTA) deployment support
- HANA Cloud database integration
- XSUAA authentication
- Destination service integration
- Application logging

## Project Structure

```
├── app/                          # UI Applications
│   ├── index.html               # Upload interface
│   ├── upload.html              # Document upload page
│   └── orders/                  # Fiori Orders application
├── db/                          # Database Layer
│   └── schema.cds               # Data model (ShipmentTracking)
├── srv/                         # Service Layer
│   ├── catalog-service.cds      # OData service definitions
│   ├── catalog-service.js       # Service implementation
│   ├── aiHelper.js              # AI document processing
│   ├── trackingService.js       # DHL/FedEx tracking
│   ├── emailService.js          # Outlook email integration
│   ├── sharepointService.js     # SharePoint operations
│   ├── excelExportService.js    # Excel report generation
│   ├── workflowService.js       # SAP Build integration
│   └── scheduled-jobs.js        # Automated tracking refresh
├── docs/                        # Documentation
│   ├── BTP_DEPLOYMENT.md        # Deployment guide
│   ├── SHIPMENT_TRACKING.md     # Tracking API docs
│   ├── EXCEL_EXPORT.md          # Export service docs
│   ├── SHAREPOINT_SETUP.md      # SharePoint configuration
│   └── MS_GRAPH_DESTINATION_SETUP.md
├── files/                       # File Storage
│   └── exports/                 # Generated Excel files
├── mta.yaml                     # BTP deployment descriptor
├── xs-security.json             # Security configuration
└── package.json                 # Dependencies

```

## Technology Stack

- **Backend**: SAP CAP (Node.js), Express.js
- **Database**: HANA Cloud (production), SQLite (development)
- **AI/ML**: SAP AI Core with Azure OpenAI models
- **Authentication**: XSUAA, Azure AD (MSAL)
- **Microsoft 365**: Microsoft Graph API
- **Logistics APIs**: DHL Tracking API, FedEx Track API
- **File Processing**: pdf-parse, pdfjs-dist, xlsx, multer
- **Cloud Platform**: SAP BTP (Cloud Foundry)

## Prerequisites

- Node.js v18 or higher
- npm (comes with Node.js)
- Cloud Foundry CLI (for BTP deployment)
- SAP BTP account with:
  - HANA Cloud instance
  - AI Core service (with Azure OpenAI deployment)
  - Destination service
  - XSUAA service
- Microsoft 365 account with:
  - Azure AD app registration
  - Microsoft Graph API permissions
  - SharePoint site access
- DHL and FedEx API credentials

## Installation

1. **Clone and install dependencies:**

```bash
npm install
```

2. **Configure environment variables:**

Create a `.env` file with the required credentials:

```env
# Microsoft Graph API
TENANT_ID=your-tenant-id
CLIENT_ID=your-client-id
CLIENT_SECRET=your-client-secret

# SharePoint
SHAREPOINT_TENANT_ID=your-tenant-id
SHAREPOINT_CLIENT_ID=your-client-id
SHAREPOINT_CLIENT_SECRET=your-client-secret
SHAREPOINT_SITE_URL=https://yourtenant.sharepoint.com/sites/YourSite
SHAREPOINT_LIBRARY_NAME=Documents
SHAREPOINT_FOLDER_PATH=Tracking Reports

# DHL API
DHL_API_KEY=your-dhl-api-key

# FedEx API
FEDEX_API_KEY=your-fedex-api-key
FEDEX_SECRET_KEY=your-fedex-secret-key

# SAP AI Core (configured via BTP destination)
```

## Running the Application

### Development Mode

```bash
npm run watch
```

The service will be available at: http://localhost:4004

### Production Mode

```bash
npm start
```

### Testing Specific Features

```bash
# Test shipment tracking
npm run test:tracking
```

## API Endpoints

### Core Services

**Base URL**: `/odata/v4/catalog`

#### Document Processing

- `POST /uploadFile` - Upload and process document (PDF/Image)
- `POST /processFileFromFolder` - Process file from local folder
- `POST /processFileFromSharePoint` - Process file from SharePoint

#### Email Operations

- `POST /listUserEmails` - List emails from user inbox
- `POST /processEmailWithAttachment` - Process email attachment as PO
- `POST /getEmailsFromDestination` - Get emails via BTP Destination
- `POST /searchEmailsFromDestination` - Search emails

#### SharePoint Operations

- `POST /listSharePointFiles` - List files in SharePoint library

#### Shipment Tracking

- `POST /trackShipment` - Track single shipment (DHL/FedEx)
- `POST /trackShipmentFromItems` - Track multiple shipments from items array
- `POST /refreshTracking` - Manually trigger tracking refresh
- `GET /ShipmentTracking` - View all tracked shipments

#### Workflow Integration

- `POST /ReceiveNotification` - Receive workflow notifications

## Key Services Explained

### 1. AI Document Processing (`aiHelper.js`)

Extracts structured data from PO documents:

```javascript
const result = await analyzeImagePrompt(base64Image);
// Returns: { PONumber, items: [...], totalAmount, ... }
```

### 2. Shipment Tracking (`trackingService.js`)

Unified tracking for DHL and FedEx:

```javascript
const result = await trackShipment("123456789", "DHL");
// Auto-generates Excel report and uploads to SharePoint
```

### 3. Email Service (`emailService.js`)

Microsoft Outlook integration:

```javascript
const emails = await listUserEmails("user@company.com");
const attachment = await downloadEmailAttachment(emailId, attachmentId);
```

### 4. SharePoint Service (`sharepointService.js`)

Document management:

```javascript
const file = await downloadFileFromSharePoint(siteUrl, libraryName, fileName);
await postFileToSharePoint(siteUrl, libraryName, folder, fileName, buffer);
```

### 5. Excel Export (`excelExportService.js`)

Automated report generation:

```javascript
const filePath = exportTrackingEventsSimplified(trackingResults);
// Creates: files/exports/shipment_tracking_YYYY-MM-DDTHH-MM-SS.xlsx
```

### 6. Scheduled Jobs (`scheduled-jobs.js`)

Automatic tracking refresh every 6 hours for active shipments.

## Data Model

### ShipmentTracking Entity

```
- trackingNumber (Key)  : String(30)
- carrier               : String(20)  // DHL, FEDEX
- deliveryStatus        : String(20)  // in_transit, delivered
- deliveryDate          : DateTime
- deliveryLocation      : String(200)
- lastStatus            : String(500)
- lastUpdatedAt         : Timestamp
- isActive              : Boolean
- poNumber              : String(50)
- description           : String(500)
```

## Deployment to SAP BTP

### 1. Build MTA Archive

```bash
mbt build
```

### 2. Login to Cloud Foundry

```bash
cf login -a https://api.cf.eu10.hana.ondemand.com
```

### 3. Deploy

```bash
npm run deploy
```

See [BTP_DEPLOYMENT.md](docs/BTP_DEPLOYMENT.md) for detailed deployment guide.

## Documentation

Detailed documentation available in the `docs/` folder:

- [BTP Deployment Guide](docs/BTP_DEPLOYMENT.md)
- [Shipment Tracking API](docs/SHIPMENT_TRACKING.md)
- [Excel Export Service](docs/EXCEL_EXPORT.md)
- [SharePoint Integration](docs/SHAREPOINT_SETUP.md)
- [Microsoft Graph Setup](docs/MS_GRAPH_DESTINATION_SETUP.md)
- [Automatic SharePoint Upload](docs/AUTOMATIC_SHAREPOINT_UPLOAD.md)
- [Integration Examples](docs/INTEGRATION_EXAMPLE.md)

## Support & Resources

- [SAP CAP Documentation](https://cap.cloud.sap/docs/)
- [SAP AI Core](https://help.sap.com/docs/AI_CORE)
- [Microsoft Graph API](https://docs.microsoft.com/graph/)
- [DHL Tracking API](https://developer.dhl.com/)
- [FedEx Developer Portal](https://developer.fedex.com/)

## License

UNLICENSED - Private project

## License

This is a sample project for learning purposes.
