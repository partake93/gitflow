using { sap.capire.salesorder as db } from '../db/schema';

service CatalogService @(path: '/odata/v4/catalog') {
    
  // Expose shipment tracking entity
  entity ShipmentTracking as projection on db.ShipmentTracking;
  
  action uploadFile(fileName: String, fileContent: LargeString) returns String;
  
  action processFileFromFolder(
    fileName: String,
    recipient: String,
    senderEmail: String
  ) returns String;
  
  action processFileFromSharePoint(
    fileName: String,
    siteUrl: String,
    libraryName: String,
    recipient: String,
    senderEmail: String
  ) returns String;
  
  action listSharePointFiles(
    siteUrl: String,
    libraryName: String,
    folderPath: String
  ) returns String;
  
  action sendPOEmail(
    recipient: String,
    senderEmail: String,
    poData: LargeString
  ) returns String;
  
  action processEmailWithAttachment(
    userEmail: String,
    emailId: String,
    recipient: String
  ) returns String;
  
  action listUserEmails(
    userEmail: String,
    folderId: String,
    maxMessages: Integer
  ) returns String;
  
  function getMailAttachments() returns String;

  action ReceiveNotification(notification: String) returns String;
  
  // Email Service using SAP BTP Destination
  action getEmailsFromDestination(
    userEmail: String,
    folderId: String,
    maxMessages: Integer
  ) returns String;
  
  action getEmailDetailsFromDestination(
    userEmail: String,
    emailId: String
  ) returns String;
  
  action getEmailAttachmentsFromDestination(
    userEmail: String,
    emailId: String
  ) returns String;
  
  action downloadAttachmentFromDestination(
    userEmail: String,
    emailId: String,
    attachmentId: String
  ) returns String;
  
  action searchEmailsFromDestination(
    userEmail: String,
    searchQuery: String,
    maxResults: Integer
  ) returns String;

  // Unified Shipment Tracking Service
  action trackShipment(
    trackingNumber: String,
    carrier: String
  ) returns String;
  
  action trackShipmentFromItems(
    items: LargeString
  ) returns String;
  
  // Scheduled refresh tracking action
  action refreshTracking() returns String;
}

