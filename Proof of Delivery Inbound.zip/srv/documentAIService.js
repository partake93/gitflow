const axios = require("axios");

class DocumentAIService {
  constructor() {
    this.accessToken = null;
  }

  async authenticate() {
    try {
      console.log("Authenticating with SAP Document Information Extraction...");

      const tokenResponse = await axios.post(
        `${process.env.DOC_AI_AUTH_URL}/oauth/token`,
        new URLSearchParams({
          grant_type: "client_credentials",
          client_id: process.env.DOC_AI_CLIENT_ID,
          client_secret: process.env.DOC_AI_CLIENT_SECRET,
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        },
      );

      this.accessToken = tokenResponse.data.access_token;
      console.log("Document AI access token obtained successfully");
      return this.accessToken;
    } catch (error) {
      console.error("Document AI authentication failed:", error.message);
      throw error;
    }
  }

  getFileType(fileName) {
    const ext = fileName.toLowerCase().split(".").pop();
    const mimeTypes = {
      pdf: "application/pdf",
      jpg: "image/jpeg",
      jpeg: "image/jpeg",
      png: "image/png",
      tiff: "image/tiff",
      tif: "image/tiff",
    };
    return mimeTypes[ext] || "application/pdf";
  }

  async extractPurchaseOrder(fileDataBase64, fileName) {
    try {
      console.log("Starting Document AI extraction...");
      console.log("File name:", fileName);

      if (!this.accessToken) {
        await this.authenticate();
      }

      const fileType = this.getFileType(fileName);
      console.log("Detected file type:", fileType);

      // Convert base64 to Buffer
      const fileBuffer = Buffer.from(fileDataBase64, "base64");

      // Prepare form data
      const FormData = require("form-data");
      const formData = new FormData();

      // Add the file
      formData.append("file", fileBuffer, {
        filename: fileName,
        contentType: fileType,
      });

      // Add options as JSON string
      const options = {
        schemaName: "purchaseOrder_schema_copy", // Remove schema to use OCR extraction SAP_purchaseOrder_schema
        clientId: "default",
        documentType: "purchase_order",
        receivedDate: new Date().toISOString().split("T")[0], // YYYY-MM-DD format
        // extraction: {
        //   headerFields: ["*"], // Extract all fields
        //   lineItems: [],
        // },
      };

      formData.append("options", JSON.stringify(options));

      console.log("Sending document to Document Information Extraction API...");
      const postUri = `${process.env.DOC_AI_BASE_URL}/document-information-extraction/v1/document/jobs`;

      // Submit document for processing
      const extractionResponse = await axios.post(postUri, formData, {
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          ...formData.getHeaders(),
        },
      });

      const jobId = extractionResponse.data.id;
      console.log("Document extraction job created:", jobId);

      // Poll for results
      const extractedData = await this.pollExtractionResults(jobId);
      //   console.log("extractedData:::::::", extractedData);

      // Transform Document AI response to expected PO format
      const transformedData = this.transformToPoFormat(extractedData);

      return transformedData;
    } catch (error) {
      console.error("Document AI extraction failed:", error.message);
      if (error.response) {
        console.error("Error status:", error.response.status);
        console.error(
          "Error data:",
          JSON.stringify(error.response.data, null, 2),
        );
      }
      throw error;
    }
  }

  async pollExtractionResults(jobId, maxAttempts = 30) {
    console.log("Polling for extraction results...");

    for (let i = 0; i < maxAttempts; i++) {
      await new Promise((resolve) => setTimeout(resolve, 2000)); // Wait 2 seconds

      const response = await axios.get(
        `${process.env.DOC_AI_BASE_URL}/document-information-extraction/v1/document/jobs/${jobId}`,
        {
          headers: {
            Authorization: `Bearer ${this.accessToken}`,
          },
        },
      );

      const status = response.data.status;
      console.log(`Job status (attempt ${i + 1}/${maxAttempts}):`, status);

      if (status === "DONE") {
        console.log("Extraction completed successfully");
        return response.data.extraction;
      } else if (status === "FAILED") {
        throw new Error(
          `Document extraction failed: ${response.data.error || "Unknown error"}`,
        );
      }
    }

    throw new Error("Document extraction timeout - exceeded maximum attempts");
  }

  transformToPoFormat(extraction) {
    console.log("Transforming Document AI response to PO format...");
    // console.log(
    //   "Full extraction response:",
    //   JSON.stringify(extraction, null, 2),
    // );

    const headerFields = extraction.headerFields || [];
    const lineItems = extraction.lineItems || [];

    console.log(`Number of line items detected: ${lineItems.length}`);

    // console.log("headerFields:::::::", headerFields);
    console.log("lineItems:::::::", lineItems);

    // Helper function to get field value
    const getFieldValue = (fields, ...names) => {
      for (const name of names) {
        const field = fields.find(
          (f) =>
            f.name === name ||
            f.label === name ||
            f.name?.toLowerCase() === name.toLowerCase(),
        );
        if (field && field.value) {
          return field.value;
        }
      }
      return "";
    };

    // Extract header information
    const header = {
      //   PONumber:
      //     getFieldValue(
      //       headerFields,
      //       "housebillNumber",
      //       "shipToHouseNumber",
      //       "trackingNumber",
      //       "documentNumber",
      //       "purchaseOrderNumber",
      //       "poNumber",
      //       "orderNumber",
      //     ) || "",
      Date:
        getFieldValue(
          headerFields,
          "documentDate",
          "orderDate",
          "date",
          "issueDate",
        ) || "",
      ContactPerson:
        getFieldValue(
          headerFields,
          "senderName",
          "supplier",
          "vendorName",
          "contactPerson",
        ) || "",
      DeliverTo:
        getFieldValue(
          headerFields,
          "deliveryAddress",
          "shipTo",
          "deliverTo",
          "shipToAddress",
        ) || "",
      TermsOfDelivery:
        getFieldValue(
          headerFields,
          "deliveryTerms",
          "incoterms",
          "termsOfDelivery",
        ) || "",
      TermsOfPayment:
        getFieldValue(headerFields, "paymentTerms", "termsOfPayment") || "",
      Currency: getFieldValue(headerFields, "currencyCode", "currency") || "",
      DeliveryDate:
        getFieldValue(
          headerFields,
          "deliveryDate",
          "requestedDeliveryDate",
          "expectedDeliveryDate",
        ) || "",
    };

    // Extract line items
    const items = lineItems.map((item, index) => {
      const getItemValue = (...names) => {
        for (const name of names) {
          const field = item.find(
            (f) =>
              f.name === name ||
              f.label === name ||
              f.name?.toLowerCase() === name.toLowerCase(),
          );
          // Only log if field exists to reduce noise
          if (field && field.value) {
            console.log(`Found item field '${name}':`, field.value);
            return field.value;
          }
        }
        return ""; // Return empty string if not found (normal for shipping labels)
      };

      return {
        PO:
          getItemValue(
            "housebillNumber",
            "shipToHouseNumber",
            "trackingNumber",
            "documentNumber",
            "purchaseOrderNumber",
            "poNumber",
            "orderNumber",
          ) || "",
        ETA: getItemValue(
          "deliveryDate",
          "documentDate",
          "itemDeliveryDate",
          "dispatchDate",
        ),
        InboundTracking: getItemValue(
          "materialNumber",
          "supplierMaterialNumber",
          "productId",
          "material",
          "sku",
        ),
        InboundLogistics: getItemValue(
          "description",
          "itemDescription",
          "productDescription",
        ),
        Item:
          getItemValue("lineNumber", "position", "item", "itemNumber") ||
          String(index + 1),
        // OrderQuantity: getItemValue("quantity", "orderQuantity", "qty"),
        // Unit: getItemValue("unitOfMeasure", "unit", "uom"),
        // RateCond: getItemValue("unitPrice", "price", "rate"),
        // RateUnit: getItemValue("priceUnit", "rateUnit"),
        // CondPriceUnit: getItemValue("pricingUnit", "pricePerUnit"),
        // CondValue: getItemValue("netAmount", "lineTotal", "amount", "value"),
        // CondUnit: getItemValue("amountUnit", "valueUnit"),
      };
    });

    const result = { header, items };
    console.log(
      "Document AI transformation complete:",
      JSON.stringify(result, null, 2),
    );
    return result;
  }

  isSupportedFileType(fileName) {
    const supportedExtensions = [
      ".pdf",
      ".jpg",
      ".jpeg",
      ".png",
      ".tiff",
      ".tif",
    ];
    const ext = fileName.toLowerCase();
    return supportedExtensions.some((supported) => ext.endsWith(supported));
  }
}

module.exports = new DocumentAIService();
