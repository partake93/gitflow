const axios = require("axios");

async function getAttachment() {
  try {
    const tokenResponse = await axios.post(
      `${process.env.OUTLOOK_AUTH_URL}`,
      new URLSearchParams({
        grant_type: "client_credentials",
        scope: `${process.env.OUTLOOK_SCOPE}`,
      }),
      {
        auth: {
          username: process.env.OUTLOOK_CLIENT_ID,
          password: process.env.OUTLOOK_CLIENT_SECRET,
        },
      },
    );
    const accessToken = tokenResponse.data.access_token;
    const headers = {
      "Content-Type": "application/json",
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
    };
    const monitorEmail =
      process.env.OUTLOOK_MONITOR_EMAIL ||
      "saketsahigds@5dglds.onmicrosoft.com";
    const getMessageUri = `${process.env.OUTLOOK_BASE_URL}/users/${monitorEmail}/messages`;

    // Get latest email
    let mails = await axios.get(getMessageUri, { headers });
    console.log("Latest email:", mails.data.value[0]?.subject);

    if (!mails.data.value || mails.data.value.length === 0) {
      throw new Error("No emails found in mailbox");
    }

    const latestEmail = mails.data.value[0];
    const mail_id = latestEmail.id;
    console.log("mail_id:::::::", mail_id);

    let extractedFile = null;

    // Check for attachments first
    if (latestEmail.hasAttachments) {
      const getAttachmentUri = `${getMessageUri}/${mail_id}/attachments`;
      let attList = await axios.get(getAttachmentUri, { headers });

      console.log(`Found ${attList.data.value.length} attachments`);

      for (const attachment of attList.data.value) {
        if (attachment.contentBytes) {
          const isImage = attachment.contentType?.startsWith("image/");
          const isPDF =
            attachment.contentType === "application/pdf" ||
            attachment.name?.toLowerCase().endsWith(".pdf");

          if (isPDF || isImage) {
            extractedFile = {
              contentBytes: attachment.contentBytes,
              fileName: attachment.name,
              contentType: attachment.contentType,
              source: "attachment",
            };
            console.log(`Selected attachment: ${attachment.name}`);
            break;
          }
        }
      }
    }

    // If no attachment found, check email body for inline images
    if (!extractedFile) {
      console.log(
        "No attachment found, checking email body for inline images...",
      );

      const emailDetails = await axios.get(
        `${getMessageUri}/${mail_id}?$select=body`,
        { headers },
      );

      const emailBody = emailDetails.data.body?.content || "";

      if (emailBody.includes("<img")) {
        // First, check for CID references (e.g., <img src="cid:image001">)
        const cidRegex = /<img[^>]+src="cid:([^"]+)"/gi;
        const cidMatches = [];
        let cidMatch;

        while ((cidMatch = cidRegex.exec(emailBody)) !== null) {
          cidMatches.push(cidMatch[1]);
        }

        if (cidMatches.length > 0) {
          console.log(`Found ${cidMatches.length} CID references:`, cidMatches);

          // Get all attachments to find CID matches
          const getAttachmentUri = `${getMessageUri}/${mail_id}/attachments`;
          let attList = await axios.get(getAttachmentUri, { headers });

          // Find attachment matching CID
          for (const cid of cidMatches) {
            const cidAttachment = attList.data.value.find(
              (att) => att.contentId === cid || att.contentId === `<${cid}>`,
            );

            if (cidAttachment && cidAttachment.contentBytes) {
              extractedFile = {
                contentBytes: cidAttachment.contentBytes,
                fileName: cidAttachment.name || `cid-image-${cid}`,
                contentType: cidAttachment.contentType,
                source: "cid-attachment",
              };
              console.log(
                `Extracted CID image: ${cid} (${cidAttachment.name})`,
              );
              break;
            }
          }
        }

        // If no CID match, check for base64 inline images
        if (!extractedFile) {
          const base64ImageRegex =
            /<img[^>]+src="data:image\/(png|jpeg|jpg|gif);base64,([^"]+)"/i;
          const match = base64ImageRegex.exec(emailBody);

          if (match) {
            const imageType = match[1];
            const base64Data = match[2];

            extractedFile = {
              contentBytes: base64Data,
              fileName: `inline-image.${imageType}`,
              contentType: `image/${imageType}`,
              source: "email-body",
            };
            console.log(
              `Extracted inline image from email body (${imageType})`,
            );
          }
        }
      }
    }

    if (!extractedFile) {
      throw new Error("No PDF or image found in email attachments or body");
    }

    return extractedFile;
  } catch (error) {
    console.error("Error getting attachment:", error.message);
    throw new Error(`Email processing error: ${error.message}`);
  }
}

module.exports = { getAttachment };
