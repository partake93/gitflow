const XLSX = require("xlsx");
const path = require("path");
const fs = require("fs");

/**
 * Export shipment tracking events to Excel file
 * @param {Array} trackingResults - Array of tracking results from trackShipmentsFromAIResult
 * @param {String} outputFileName - Name of the output Excel file (optional)
 * @returns {String} - Path to the generated Excel file
 */
function exportTrackingEventsToExcel(trackingResults, outputFileName = null) {
  console.log("[exportTrackingEventsToExcel] Starting export", {
    resultsCount: trackingResults.length,
    timestamp: new Date().toISOString(),
  });

  // Create array to hold all rows
  const excelData = [];

  // Process each tracking result
  trackingResults.forEach((result) => {
    if (result.status !== "success" || !result.trackingData) {
      console.log("[exportTrackingEventsToExcel] Skipping result", {
        trackingNumber: result.trackingNumber,
        status: result.status,
      });
      return;
    }

    const { trackingNumber, carrier, trackingData } = result;

    // Add header row for this tracking number
    excelData.push({
      "Tracking Number": trackingNumber,
      Carrier: carrier,
      Time: "",
      "Status Update": "=== TRACKING DETAILS ===",
      Location: "",
    });

    // Extract events based on carrier
    let events = [];

    if (carrier === "DHL" && trackingData.shipments) {
      // DHL format
      trackingData.shipments.forEach((shipment) => {
        if (shipment.events && Array.isArray(shipment.events)) {
          const shipmentEvents = shipment.events.map((event) => ({
            timestamp: event.timestamp,
            description:
              event.description || event.statusCode || "Status Update",
            location: formatDHLLocation(event.location),
          }));
          events = events.concat(shipmentEvents);
        }
      });
    } else if (carrier === "FEDEX" && trackingData.output) {
      // FedEx format
      const trackResults = trackingData.output.completeTrackResults || [];
      trackResults.forEach((track) => {
        if (track.trackResults && track.trackResults[0]?.scanEvents) {
          const fedexEvents = track.trackResults[0].scanEvents.map((event) => ({
            timestamp: event.date,
            description:
              event.eventDescription ||
              event.derivedStatusCode ||
              "Status Update",
            location: formatFedExLocation(event.scanLocation),
          }));
          events = events.concat(fedexEvents);
        }
      });
    }

    // Sort events by timestamp (most recent first)
    events.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    // Add events to Excel data
    events.forEach((event, index) => {
      const formattedTime = formatTimestamp(event.timestamp);

      excelData.push({
        "Tracking Number": index === 0 ? trackingNumber : "",
        Carrier: index === 0 ? carrier : "",
        Time: formattedTime,
        "Status Update": event.description,
        Location: event.location,
      });
    });

    // Add separator row
    excelData.push({
      "Tracking Number": "",
      Carrier: "",
      Time: "",
      "Status Update": "",
      Location: "",
    });
  });

  // Create worksheet
  const worksheet = XLSX.utils.json_to_sheet(excelData);

  // Set column widths
  worksheet["!cols"] = [
    { wch: 20 }, // Tracking Number
    { wch: 10 }, // Carrier
    { wch: 25 }, // Time
    { wch: 40 }, // Status Update
    { wch: 30 }, // Location
  ];

  // Create workbook
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Tracking Events");

  // Generate file name with tracking numbers
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);

  let fileName = outputFileName;
  if (!fileName) {
    // Collect tracking numbers from results
    const trackingNumbers = trackingResults
      .filter((r) => r.trackingNumber)
      .map((r) => r.trackingNumber)
      .slice(0, 3); // Limit to first 3 tracking numbers

    if (trackingNumbers.length > 0) {
      const trackingPart = trackingNumbers.join("_");
      fileName = `tracking_${trackingPart}_${timestamp}.xlsx`;
    } else {
      fileName = `shipment_tracking_${timestamp}.xlsx`;
    }
  }

  // Ensure files directory exists
  const filesDir = path.join(__dirname, "..", "files", "exports");
  if (!fs.existsSync(filesDir)) {
    fs.mkdirSync(filesDir, { recursive: true });
  }

  const filePath = path.join(filesDir, fileName);

  // Write file
  XLSX.writeFile(workbook, filePath);

  console.log("[exportTrackingEventsToExcel] Export completed", {
    filePath,
    rowCount: excelData.length,
    timestamp: new Date().toISOString(),
  });

  return filePath;
}

/**
 * Format DHL location object to string
 */
function formatDHLLocation(location) {
  if (!location) return "";

  // Prioritize city/locality name
  if (location.address && location.address.addressLocality) {
    return location.address.addressLocality;
  }

  // Fallback to country code if no city
  if (location.address && location.address.countryCode) {
    return location.address.countryCode;
  }

  return "";
}

/**
 * Format FedEx location object to string
 */
function formatFedExLocation(location) {
  if (!location) return "";

  const parts = [];
  if (location.city) parts.push(location.city);
  if (location.stateOrProvinceCode) parts.push(location.stateOrProvinceCode);
  if (location.countryCode) parts.push(location.countryCode);

  return parts.join(", ") || "N/A";
}

/**
 * Format timestamp to readable format
 * Handles ISO 8601 timestamps: "2026-01-20T13:02:00Z" or "2026-01-28T17:28:00+08:00"
 */
function formatTimestamp(timestamp) {
  if (!timestamp) return "";

  try {
    let timestampStr = timestamp;

    // Handle "Z" timezone (UTC) - convert to +00:00 format for consistency
    if (typeof timestampStr === "string" && timestampStr.endsWith("Z")) {
      timestampStr = timestampStr.replace("Z", "+00:00");
    }

    // Parse the ISO 8601 timestamp
    const date = new Date(timestampStr);

    if (isNaN(date.getTime())) {
      console.error("[formatTimestamp] Invalid date:", timestamp);
      return timestamp;
    }

    // Extract timezone offset from original string
    let timezoneOffset = "+00:00";
    let timezoneMinutes = 0;

    if (typeof timestampStr === "string") {
      const tzMatch = timestampStr.match(/([+-]\d{2}:\d{2})$/);
      if (tzMatch) {
        timezoneOffset = tzMatch[1];
        // Parse timezone offset to minutes (e.g., "+08:00" -> 480 minutes)
        const [sign, hours, minutes] = tzMatch[1]
          .match(/([+-])(\d{2}):(\d{2})/)
          .slice(1);
        timezoneMinutes =
          (parseInt(hours) * 60 + parseInt(minutes)) * (sign === "+" ? 1 : -1);
      }
    }

    // Get UTC components
    const utcDay = date.getUTCDate();
    const utcMonth = date.getUTCMonth();
    const utcYear = date.getUTCFullYear();
    let utcHours = date.getUTCHours();
    let utcMinutes = date.getUTCMinutes();

    // Apply timezone offset to get local time in that timezone
    const totalMinutes = utcHours * 60 + utcMinutes + timezoneMinutes;
    let localHours = Math.floor(totalMinutes / 60) % 24;
    if (localHours < 0) localHours += 24;
    const localMinutes = totalMinutes % 60;

    // Calculate day offset if time crosses date boundary
    let dayOffset = Math.floor(totalMinutes / (24 * 60));
    const localDate = new Date(Date.UTC(utcYear, utcMonth, utcDay + dayOffset));

    const localDay = localDate.getUTCDate();
    const localMonthName = localDate.toLocaleString("en-US", {
      month: "long",
      timeZone: "UTC",
    });
    const localYear = localDate.getUTCFullYear();

    // Format time with AM/PM
    const ampm = localHours >= 12 ? "pm" : "am";
    let hours12 = localHours % 12;
    hours12 = hours12 ? hours12 : 12; // 0 should be 12
    const timeStr = `${hours12}:${String(localMinutes).padStart(2, "0")} ${ampm}`;

    // Format timezone
    const timezone =
      timezoneOffset === "+00:00" ? "UTC" : `UTC ${timezoneOffset}`;

    return `${localDay} ${localMonthName} ${localYear}\n${timeStr} (${timezone})`;
  } catch (error) {
    console.error("[formatTimestamp] Error formatting timestamp:", error, {
      timestamp,
      error: error.message,
    });
    return timestamp;
  }
}

/**
 * Export tracking events with simplified format (Time, Status Update, Location only)
 */
function exportTrackingEventsSimplified(
  trackingResults,
  outputFileName = null,
) {
  console.log("[exportTrackingEventsSimplified] Starting export", {
    resultsCount: trackingResults.length,
    timestamp: new Date().toISOString(),
  });

  const excelData = [];

  trackingResults.forEach((result, resultIdx) => {
    console.log(
      `[exportTrackingEventsSimplified] Processing result ${resultIdx + 1}:`,
      {
        trackingNumber: result.trackingNumber,
        carrier: result.carrier,
        status: result.status,
        hasTrackingData: !!result.trackingData,
      },
    );

    if (result.status !== "success" || !result.trackingData) {
      console.log(
        `[exportTrackingEventsSimplified] Skipping result ${resultIdx + 1} - no valid tracking data`,
      );
      return;
    }

    const { trackingNumber, carrier, trackingData } = result;
    let events = [];

    // console.log(
    //   `[exportTrackingEventsSimplified] Raw tracking data for ${trackingNumber}:`,
    //   JSON.stringify(trackingData, null, 2),
    // );

    // Extract events based on carrier
    if (carrier === "DHL" && trackingData.shipments) {
      console.log(
        `[exportTrackingEventsSimplified] Processing ${trackingData.shipments.length} DHL shipments`,
      );

      trackingData.shipments.forEach((shipment, shipmentIdx) => {
        console.log(
          `[exportTrackingEventsSimplified] Shipment ${shipmentIdx + 1}:`,
          {
            id: shipment.id,
            hasEvents: !!shipment.events,
            eventCount: shipment.events ? shipment.events.length : 0,
          },
        );

        if (shipment.events && Array.isArray(shipment.events)) {
          console.log(
            `[exportTrackingEventsSimplified] Found ${shipment.events.length} events for shipment ${shipment.id}`,
          );

          // Accumulate all events from all shipments
          const shipmentEvents = shipment.events.map((event, eventIdx) => {
            // console.log(
            //   `[exportTrackingEventsSimplified] Event ${eventIdx + 1}:`,
            //   {
            //     timestamp: event.timestamp,
            //     description: event.description,
            //     statusCode: event.statusCode,
            //     locationRaw: event.location,
            //     locationFormatted: formatDHLLocation(event.location),
            //   },
            // );

            return {
              timestamp: event.timestamp,
              description:
                event.description || event.statusCode || "Status Update",
              location: formatDHLLocation(event.location),
            };
          });

          console.log(
            `[exportTrackingEventsSimplified] Extracted ${shipmentEvents.length} events from shipment ${shipment.id}`,
          );
          events = events.concat(shipmentEvents);
          console.log(
            `[exportTrackingEventsSimplified] Total events accumulated so far: ${events.length}`,
          );
        }
      });
    } else if (carrier === "FEDEX" && trackingData.output) {
      const trackResults = trackingData.output.completeTrackResults || [];
      console.log(
        `[exportTrackingEventsSimplified] Processing ${trackResults.length} FedEx track results`,
      );

      trackResults.forEach((track, trackIdx) => {
        if (track.trackResults && track.trackResults[0]?.scanEvents) {
          console.log(
            `[exportTrackingEventsSimplified] Found ${track.trackResults[0].scanEvents.length} FedEx events`,
          );

          const fedexEvents = track.trackResults[0].scanEvents.map((event) => ({
            timestamp: event.date,
            description:
              event.eventDescription ||
              event.derivedStatusCode ||
              "Status Update",
            location: formatFedExLocation(event.scanLocation),
          }));

          events = events.concat(fedexEvents);
        }
      });
    }

    console.log(
      `[exportTrackingEventsSimplified] Total events extracted for ${trackingNumber}: ${events.length}`,
    );

    // Sort events by timestamp (most recent first)
    events.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    // Check for delivery status
    const deliveredEvent = events.find((event) =>
      event.description.toLowerCase().includes("shipment delivered"),
    );

    if (deliveredEvent) {
      const deliveryTime = formatTimestamp(deliveredEvent.timestamp);
      console.log(
        `✅ [Tracking ${trackingNumber}] Shipment Delivered at: ${deliveryTime.replace("\n", " ")}`,
      );
      console.log(`   Location: ${deliveredEvent.location}`);
    } else {
      console.log(
        `⏳ [Tracking ${trackingNumber}] Delivery date not yet received - shipment still in transit`,
      );
    }

    // Add tracking number as header
    if (events.length > 0) {
      excelData.push({
        Time: `Tracking: ${trackingNumber} (${carrier})`,
        "Status Update": "",
        Location: "",
      });
    }

    // Add events
    events.forEach((event) => {
      const formattedTime = formatTimestamp(event.timestamp);
      excelData.push({
        Time: formattedTime,
        "Status Update": event.description,
        Location: event.location,
      });
    });

    // Add separator
    excelData.push({
      Time: "",
      "Status Update": "",
      Location: "",
    });
  });

  // Create worksheet
  const worksheet = XLSX.utils.json_to_sheet(excelData);

  // Set column widths
  worksheet["!cols"] = [
    { wch: 25 }, // Time
    { wch: 40 }, // Status Update
    { wch: 30 }, // Location
  ];

  // Create workbook
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Tracking Events");

  // Generate file name with tracking numbers
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);

  let fileName = outputFileName;
  if (!fileName) {
    // Collect tracking numbers from results
    const trackingNumbers = trackingResults
      .filter((r) => r.trackingNumber)
      .map((r) => r.trackingNumber)
      .slice(0, 3); // Limit to first 3 tracking numbers

    if (trackingNumbers.length > 0) {
      const trackingPart = trackingNumbers.join("_");
      fileName = `tracking_${trackingPart}_${timestamp}.xlsx`;
    } else {
      fileName = `shipment_tracking_${timestamp}.xlsx`;
    }
  }

  // Ensure files directory exists
  const filesDir = path.join(__dirname, "..", "files", "exports");
  if (!fs.existsSync(filesDir)) {
    fs.mkdirSync(filesDir, { recursive: true });
  }

  const filePath = path.join(filesDir, fileName);

  // Write file
  XLSX.writeFile(workbook, filePath);

  console.log("[exportTrackingEventsSimplified] Export completed", {
    filePath,
    rowCount: excelData.length,
    timestamp: new Date().toISOString(),
  });

  return filePath;
}

module.exports = {
  exportTrackingEventsToExcel,
  exportTrackingEventsSimplified,
};
