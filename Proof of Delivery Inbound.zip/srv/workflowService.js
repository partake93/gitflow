const axios = require("axios");

class WorkflowService {
  constructor() {
    this.accessToken = null;
  }

  async authenticate() {
    try {
      console.log("Authenticating with SAP Workflow Service...");

      const tokenResponse = await axios.post(
        process.env.WORKFLOW_AUTH_URL,
        new URLSearchParams({
          client_id: process.env.WORKFLOW_CLIENT_ID,
          client_secret: process.env.WORKFLOW_CLIENT_SECRET,
          grant_type: "client_credentials",
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        },
      );

      this.accessToken = tokenResponse.data.access_token;
      console.log("Successfully obtained Workflow access token");
      return this.accessToken;
    } catch (error) {
      console.error("Workflow authentication failed:", error.message);
      throw error;
    }
  }

  async triggerWorkflow(poData, fileName) {
    try {
      console.log("Triggering workflow for PO:", poData.header?.PONumber);

      if (!this.accessToken) {
        await this.authenticate();
      }

      // Prepare workflow context
      const workflowContext = {
        poNumber: poData.header?.PONumber || "Unknown",
        deliverydate: poData.header?.Date || "",
        supplier: poData.header?.ContactPerson || "",
        // deliverTo: poData.header?.DeliverTo || "",
        currency: poData.header?.Currency || "",
        items: (poData.items || []).map((item, index) => ({
          lineNumber: index + 1,
          material: item.Material,
          description: item.Description,
          quantity: item.OrderQuantity,
          unit: item.Unit,
          value: item.CondValue,
        })),
        filename: fileName,
        // extractedData: poData,
        // createdAt: new Date().toISOString(),
        // status: "Pending Review",
      };

      // Create workflow instance
      const response = await axios.post(
        `${process.env.WORKFLOW_API_URL}/v1/workflow-instances`,
        {
          definitionId: process.env.WORKFLOW_DEFINITION_ID || "po_approval",
          context: workflowContext,
        },
        {
          headers: {
            Authorization: `Bearer ${this.accessToken}`,
            "Content-Type": "application/json",
          },
        },
      );

      console.log(
        "Workflow triggered successfully, Instance ID:",
        response.data.id,
      );

      return {
        success: true,
        workflowInstanceId: response.data.id,
        status: response.data.status,
        message: "Workflow instance created successfully",
      };
    } catch (error) {
      console.error("Workflow trigger failed:", error.message);
      if (error.response) {
        console.error("Error status:", error.response.status);
        console.error(
          "Error data:",
          JSON.stringify(error.response.data, null, 2),
        );
      }
      return {
        success: false,
        error: error.message,
        message: "Failed to trigger workflow",
      };
    }
  }

  async createMyInboxTask(poData, fileName, assignee) {
    try {
      console.log("Creating MyInbox task for PO:", poData.header?.PONumber);

      if (!this.accessToken) {
        await this.authenticate();
      }

      // For SAP Build Process Automation, use workflow-instances with context
      const workflowPayload = {
        definitionId: process.env.WORKFLOW_DEFINITION_ID,
        // context: {
        //   description: "This is test workflow",
        // },
        context: {
          // These must match your process inputs in SAP Build
          //   poNumber: poData.header?.PONumber || "Unknown",
          //   supplier: poData.header?.ContactPerson || "",
          //   totalItems: poData.items?.length || 0,
          //   currency: poData.header?.Currency || "",
          //   deliveryDate: poData.header?.DeliveryDate || "",
          //   fileName: fileName,
          //   assignee: assignee || process.env.DEFAULT_WORKFLOW_ASSIGNEE,
          //   // Include full data for form display
          //   header: poData.header,
          //   items: poData.items,
          //   extractedAt: new Date().toISOString(),
          //   status: "Pending Approval",
          ponumber: poData.header?.PONumber || "Unknown",
          //   deliverydate: poData.header?.Date || "",
          supplier: poData.header?.ContactPerson || "",
          assignee: assignee || process.env.DEFAULT_WORKFLOW_ASSIGNEE,
          // deliverTo: poData.header?.DeliverTo || "",
          currency: poData.header?.Currency || "",
          items: (poData.items || []).map((y) => ({
            item: y.Item,
            material: y.Material,
            description: y.Description,
            orderquantity: y.OrderQuantity,
            unit: y.Unit,
          })),
          filename: fileName,
          // extractedData: poData,
          // createdAt: new Date().toISOString(),
          // status: "Pending Review",
        },
      };

      const response = await axios.post(
        `${process.env.WORKFLOW_API_URL}/v1/workflow-instances`,
        workflowPayload,
        {
          headers: {
            Authorization: `Bearer ${this.accessToken}`,
            "Content-Type": "application/json",
          },
        },
      );

      console.log(
        "MyInbox task created successfully, Task ID:",
        response.data.id,
      );

      return {
        success: true,
        taskId: response.data.id,
        taskUrl:
          response.data.taskUrl ||
          `${process.env.MYINBOX_URL}?taskId=${response.data.id}`,
        message: "Task created in MyInbox successfully",
      };
    } catch (error) {
      console.error("MyInbox task creation failed:", error.message);
      if (error.response) {
        console.error("Error status:", error.response.status);
        console.error(
          "Error data:",
          JSON.stringify(error.response.data, null, 2),
        );
      }
      return {
        success: false,
        error: error.message,
        message: "Failed to create MyInbox task",
      };
    }
  }

  formatPOSummary(poData) {
    const header = poData.header || {};
    const items = poData.items || [];

    return {
      summary: {
        poNumber: header.PONumber,
        date: header.Date,
        supplier: header.ContactPerson,
        deliverTo: header.DeliverTo,
        currency: header.Currency,
        deliveryDate: header.DeliveryDate,
        totalLineItems: items.length,
      },
      items: items.map((item, index) => ({
        lineNumber: index + 1,
        material: item.Material,
        description: item.Description,
        quantity: item.OrderQuantity,
        unit: item.Unit,
        value: item.CondValue,
      })),
    };
  }
}

module.exports = new WorkflowService();
