# Automatic SharePoint Upload for Tracking Reports

## Overview

After generating a shipment tracking Excel file, the system automatically uploads it to SharePoint using Microsoft Graph API.

## How It Works

1. **AI analyzes document** → Extracts items with tracking numbers
2. **Tracking service** → Calls DHL/FedEx APIs to get shipment events
3. **Excel export** → Generates formatted Excel file locally
4. **SharePoint upload** → Automatically uploads Excel to SharePoint (NEW!)

## Configuration

Add these environment variables to enable automatic SharePoint upload:

### Required Variables

```env
# SharePoint Authentication
SHAREPOINT_TENANT_ID=your-tenant-id
SHAREPOINT_CLIENT_ID=your-client-id
SHAREPOINT_CLIENT_SECRET=your-client-secret
SHAREPOINT_HOST_NAME=yourtenant.sharepoint.com

# SharePoint Site and Location
SHAREPOINT_SITE_URL=https://yourtenant.sharepoint.com/sites/YourSite
```

### Optional Variables (with defaults)

```env
# Where to upload the Excel files
SHAREPOINT_LIBRARY_NAME=Documents
SHAREPOINT_FOLDER_PATH=Tracking Reports
```

## Behavior

- **If configured**: Excel file is uploaded to SharePoint automatically after generation
- **If not configured**: Excel file is only saved locally (no error, just skips upload)
- **If upload fails**: Error is logged but process continues (Excel file still available locally)

## Return Object

The `trackShipmentsFromAIResult` function now returns:

```javascript
{
  success: true,
  totalItems: 3,
  trackingResults: [...],
  excelFilePath: "C:\\...\\tracking_DHL123_2026-02-25T10-30-15.xlsx", // Local path
  sharepointUrl: "https://tenant.sharepoint.com/sites/.../tracking_DHL123_2026-02-25T10-30-15.xlsx", // SharePoint URL
  message: "Shipment tracking completed"
}
```

## Example Usage in Service

The upload happens automatically inside `trackShipmentsFromAIResult()`:

```javascript
// In catalog-service.js
const result = await trackShipmentsFromAIResult(aiResult);

console.log("Local file:", result.excelFilePath);
console.log("SharePoint URL:", result.sharepointUrl); // null if not uploaded
```

## File Naming

Files uploaded to SharePoint use the same naming as local files:

- Single tracking: `tracking_DHL123456789_2026-02-25T10-30-15.xlsx`
- Multiple tracking: `tracking_DHL123_FDX456_DHL789_2026-02-25T10-30-15.xlsx`

## Folder Structure

Default folder structure in SharePoint:

```
Documents/
└── Tracking Reports/
    ├── tracking_DHL123456789_2026-02-25T10-30-15.xlsx
    ├── tracking_FDX987654321_2026-02-25T11-45-22.xlsx
    └── ...
```

## Testing

### Test SharePoint Upload Only

```bash
node srv/test-sharepoint-upload.js
```

### Test Complete Workflow (Tracking + Excel + SharePoint)

```bash
node srv/test-integrated-workflow.js
```

## Error Handling

The system handles failures gracefully:

1. **SharePoint not configured**: Skips upload, logs info message
2. **Authentication failure**: Logs error, continues without upload
3. **Upload failure**: Logs error with details, continues without upload
4. **Excel generation failure**: Logs error, returns without attempting upload

**Important**: Upload failures do NOT stop the tracking process. The local Excel file is always available even if SharePoint upload fails.

## Logs

Successful upload logs:

```
[trackShipmentsFromAIResult] Excel file created { filePath: '...' }
[trackShipmentsFromAIResult] Uploading Excel to SharePoint { timestamp: '...' }
Uploading file: tracking_DHL123_2026-02-25T10-30-15.xlsx to SharePoint
Site: https://tenant.sharepoint.com/sites/YourSite
Library: Documents
Folder: Tracking Reports
Authenticated with SharePoint
Site ID: abc123...
Drive ID: def456...
File uploaded successfully
File ID: 01ABC...
File web URL: https://tenant.sharepoint.com/...
[trackShipmentsFromAIResult] Excel uploaded to SharePoint { webUrl: '...', fileId: '...' }
```

Failed upload logs:

```
[trackShipmentsFromAIResult] Failed to upload Excel to SharePoint
{
  error: 'Document library 'Documents' not found',
  stack: '...'
}
```

## Permissions Required

The Azure AD app registration needs these Graph API permissions:

- `Sites.ReadWrite.All` - To access SharePoint sites and upload files
- `Files.ReadWrite.All` - To write files to SharePoint

See [MS_GRAPH_DESTINATION_SETUP.md](./MS_GRAPH_DESTINATION_SETUP.md) for setup instructions.
