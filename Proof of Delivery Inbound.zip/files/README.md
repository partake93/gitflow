# Files Folder

Place your PDF files here to process them using the `processFileFromFolder` action.

## Usage

**OData Action Endpoint:**

```
POST http://localhost:4004/odata/v4/catalog/processFileFromFolder
Content-Type: application/json

{
  "fileName": "your-document.pdf"
}
```

**Example:**

1. Place `purchase-order.pdf` in this folder
2. Call the action with:

```json
{
  "fileName": "purchase-order.pdf"
}
```

The system will automatically:

- Read the file from this folder
- Convert it to base64
- Extract text using AI
- Return the structured data
