const { Client } = require("@microsoft/microsoft-graph-client");
require("isomorphic-fetch");
const axios = require("axios");

class OutlookService {
  constructor() {
    this.client = null;
  }

  async authenticate() {
    let accessToken;

    try {
      console.log("Authenticating with Azure AD for Outlook...");
      console.log("Client ID:", process.env.OUTLOOK_CLIENT_ID);

      // Get access token using client credentials flow
      const tokenResponse = await axios.post(
        process.env.OUTLOOK_AUTH_URL,
        new URLSearchParams({
          client_id: process.env.OUTLOOK_CLIENT_ID,
          client_secret: process.env.OUTLOOK_CLIENT_SECRET,
          scope: process.env.OUTLOOK_SCOPE,
          grant_type: "client_credentials",
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        },
      );

      accessToken = tokenResponse.data.access_token;
      console.log("Successfully obtained Outlook access token");
    } catch (authError) {
      console.error("Outlook authentication failed:", authError.message);
      if (authError.response) {
        console.error("Auth error status:", authError.response.status);
        console.error(
          "Auth error data:",
          JSON.stringify(authError.response.data, null, 2),
        );
      }
      throw authError;
    }

    // Initialize Graph client
    this.client = Client.init({
      authProvider: (done) => {
        done(null, accessToken);
      },
    });

    return this.client;
  }

  async sendEmail(recipient, subject, htmlBody, senderEmail) {
    try {
      console.log("Sending email to:", recipient);
      console.log("Subject:", subject);

      if (!this.client) {
        await this.authenticate();
      }

      const message = {
        message: {
          subject: subject,
          body: {
            contentType: "HTML",
            content: htmlBody,
          },
          toRecipients: [
            {
              emailAddress: {
                address: recipient,
              },
            },
          ],
        },
        saveToSentItems: "true",
      };

      // Send email on behalf of the user
      await this.client.api(`/users/${senderEmail}/sendMail`).post(message);

      console.log("Email sent successfully!");
      return { success: true, message: "Email sent successfully" };
    } catch (error) {
      console.error("Email sending error:", error.message);
      if (error.statusCode) {
        console.error("Graph API status code:", error.statusCode);
      }
      if (error.body) {
        console.error(
          "Graph API error body:",
          JSON.stringify(error.body, null, 2),
        );
      }
      throw error;
    }
  }

  async listEmails(userEmail, folderId = "inbox", maxMessages = 10) {
    try {
      console.log(`Fetching emails from ${folderId} for user:`, userEmail);

      if (!this.client) {
        await this.authenticate();
      }

      const response = await this.client
        .api(`/users/${userEmail}/mailFolders/${folderId}/messages`)
        .top(maxMessages)
        .select(
          "id,subject,from,receivedDateTime,hasAttachments,body,bodyPreview",
        )
        .orderby("receivedDateTime DESC")
        .get();

      console.log(`Found ${response.value.length} emails`);
      return response.value;
    } catch (error) {
      console.error("Error listing emails:", error.message);
      throw error;
    }
  }

  async getEmailById(userEmail, emailId) {
    try {
      console.log("Fetching email:", emailId);

      if (!this.client) {
        await this.authenticate();
      }

      const email = await this.client
        .api(`/users/${userEmail}/messages/${emailId}`)
        .select("id,subject,from,receivedDateTime,hasAttachments,body")
        .get();

      return email;
    } catch (error) {
      console.error("Error getting email:", error.message);
      throw error;
    }
  }

  async getEmailAttachments(userEmail, emailId) {
    try {
      console.log("Fetching attachments for email:", emailId);

      if (!this.client) {
        await this.authenticate();
      }

      const attachments = await this.client
        .api(`/users/${userEmail}/messages/${emailId}/attachments`)
        .get();

      console.log(`Found ${attachments.value.length} attachments`);
      return attachments.value;
    } catch (error) {
      console.error("Error getting attachments:", error.message);
      throw error;
    }
  }

  async downloadAttachment(userEmail, emailId, attachmentId) {
    try {
      console.log("Downloading attachment:", attachmentId);

      if (!this.client) {
        await this.authenticate();
      }

      const attachment = await this.client
        .api(
          `/users/${userEmail}/messages/${emailId}/attachments/${attachmentId}`,
        )
        .get();

      // For file attachments, contentBytes contains base64 encoded data
      if (attachment.contentBytes) {
        const buffer = Buffer.from(attachment.contentBytes, "base64");
        return {
          name: attachment.name,
          contentType: attachment.contentType,
          size: attachment.size,
          buffer: buffer,
        };
      }

      return null;
    } catch (error) {
      console.error("Error downloading attachment:", error.message);
      throw error;
    }
  }

  extractTextFromEmailBody(email) {
    try {
      let bodyContent = "";

      if (email.body) {
        if (email.body.contentType === "html") {
          // Strip HTML tags for simple text extraction
          bodyContent = email.body.content.replace(/<[^>]*>/g, " ");
          bodyContent = bodyContent.replace(/&nbsp;/g, " ");
          bodyContent = bodyContent.replace(/\s+/g, " ").trim();
        } else {
          bodyContent = email.body.content;
        }
      }

      return bodyContent;
    } catch (error) {
      console.error("Error extracting email body:", error.message);
      return "";
    }
  }

  formatPODataAsHTML(poData) {
    const header = poData.header || {};
    const items = poData.items || [];

    let html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 20px;
    }
    h2 {
      color: #0078d4;
      border-bottom: 2px solid #0078d4;
      padding-bottom: 5px;
    }
    table {
      border-collapse: collapse;
      width: 100%;
      margin: 20px 0;
    }
    th {
      background-color: #0078d4;
      color: white;
      padding: 12px;
      text-align: left;
      font-weight: bold;
    }
    td {
      border: 1px solid #ddd;
      padding: 10px;
    }
    tr:nth-child(even) {
      background-color: #f2f2f2;
    }
    .header-table td:first-child {
      font-weight: bold;
      background-color: #f0f0f0;
      width: 200px;
    }
  </style>
</head>
<body>
  <h2>📄 Purchase Order Details</h2>
  
  <h3>Header Information</h3>
  <table class="header-table">
    <tr><td>PO Number</td><td>${header.PONumber || "N/A"}</td></tr>
    <tr><td>Date</td><td>${header.Date || "N/A"}</td></tr>
    <tr><td>Contact Person</td><td>${header.ContactPerson || "N/A"}</td></tr>
    <tr><td>Deliver To</td><td>${header.DeliverTo || "N/A"}</td></tr>
    <tr><td>Terms of Delivery</td><td>${header.TermsOfDelivery || "N/A"}</td></tr>
    <tr><td>Terms of Payment</td><td>${header.TermsOfPayment || "N/A"}</td></tr>
    <tr><td>Currency</td><td>${header.Currency || "N/A"}</td></tr>
    <tr><td>Delivery Date</td><td>${header.DeliveryDate || "N/A"}</td></tr>
  </table>
  
  <h3>Line Items</h3>
  <table>
    <thead>
      <tr>
        <th>Item</th>
        <th>Material</th>
        <th>Description</th>
        <th>Order Qty</th>
        <th>Unit</th>
        <th>Delivery Date</th>
        <th>Rate Cond</th>
        <th>Rate Unit</th>
        <th>Cond Price Unit</th>
        <th>Cond Value</th>
        <th>Cond Unit</th>
      </tr>
    </thead>
    <tbody>
`;

    items.forEach((item) => {
      html += `
      <tr>
        <td>${item.Item || ""}</td>
        <td>${item.Material || ""}</td>
        <td>${item.Description || ""}</td>
        <td>${item.OrderQuantity || ""}</td>
        <td>${item.Unit || ""}</td>
        <td>${item.DeliveryDate || ""}</td>
        <td>${item.RateCond || ""}</td>
        <td>${item.RateUnit || ""}</td>
        <td>${item.CondPriceUnit || ""}</td>
        <td>${item.CondValue || ""}</td>
        <td>${item.CondUnit || ""}</td>
      </tr>
`;
    });

    html += `
    </tbody>
  </table>
  
  <p style="color: #666; font-size: 12px; margin-top: 30px;">
    This email was automatically generated from PDF purchase order processing.
  </p>
</body>
</html>
`;

    return html;
  }
}

module.exports = new OutlookService();
