const cron = require("node-cron");
const cds = require("@sap/cds");

console.log("📅 Initializing scheduled jobs...");

// Run every 5 minutes to avoid database lock conflicts
const task = cron.schedule("*/5 * * * *", async () => {
  console.log("⏰ Cron job triggered at:", new Date().toISOString());

  // Add delay to ensure database is not busy
  await new Promise((resolve) => setTimeout(resolve, 1000));

  try {
    const srv = await cds.connect.to("CatalogService");
    const result = await srv.send("refreshTracking");
    console.log("✅ Tracking refreshed successfully");

    // Parse and log summary if available
    try {
      const parsedResult = JSON.parse(result);
      if (parsedResult.success) {
        console.log(
          `   📦 Total: ${parsedResult.totalShipments || 0}, ✅ Delivered: ${parsedResult.delivered || 0}, 🚚 In Transit: ${parsedResult.inTransit || 0}`,
        );
      }
    } catch (e) {
      // Ignore parsing errors
    }
  } catch (error) {
    console.error("❌ Error in scheduled tracking refresh:", error.message);

    // Only log stack trace for non-database lock errors
    if (!error.message.includes("database is locked")) {
      console.error("Stack:", error.stack);
    } else {
      console.log("   ⚠️ Database was busy, will retry on next schedule");
    }
  }
});

console.log("✅ Cron job scheduled: Every 5 minutes");
console.log("   Next run will be within 5 minutes");
console.log("   Current time:", new Date().toISOString());

module.exports = task;
