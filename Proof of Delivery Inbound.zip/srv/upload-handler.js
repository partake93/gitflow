const cds = require("@sap/cds");
const multer = require("multer");
const upload = multer({ storage: multer.memoryStorage() });

module.exports = (app) => {
  // Custom endpoint for file upload (multipart/form-data)
  app.post("/upload", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const { analyzePrompt } = require("./aiHelper");
      const fileContent = req.file.buffer.toString("base64");

      const result = await analyzePrompt(fileContent);

      res.json({
        success: true,
        data: result,
        fileName: req.file.originalname,
      });
    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({
        error: error.message,
        message: `Error processing file: ${error.message}`,
      });
    }
  });
};
