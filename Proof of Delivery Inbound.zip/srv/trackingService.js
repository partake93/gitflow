const cds = require("@sap/cds");

/**
 * Unified Shipment Tracking Service for DHL and FedEx
 */
module.exports = async function () {
  /**
   * Track shipment with explicit carrier
   */
  this.on("trackShipment", async (req) => {
    const startTime = Date.now();
    const { trackingNumber, carrier } = req.data;

    console.log("[trackShipment] Request received", {
      timestamp: new Date().toISOString(),
      trackingNumber,
      carrier,
    });

    if (!trackingNumber) {
      req.error(400, "Tracking number is required");
      return;
    }

    if (!carrier) {
      req.error(400, "Carrier is required (DHL or FedEx)");
      return;
    }

    try {
      const normalizedCarrier = carrier.toUpperCase();
      let result;

      if (normalizedCarrier === "DHL") {
        result = await trackDHL(trackingNumber);
      } else if (normalizedCarrier === "FEDEX") {
        result = await trackFedEx(trackingNumber);
      } else {
        req.error(
          400,
          `Unsupported carrier: ${carrier}. Supported carriers are DHL and FedEx`,
        );
        return;
      }

      const duration = Date.now() - startTime;
      console.log("[trackShipment] Successfully tracked shipment", {
        carrier: normalizedCarrier,
        trackingNumber,
        duration: `${duration}ms`,
        timestamp: new Date().toISOString(),
      });

      return JSON.stringify({
        success: true,
        carrier: normalizedCarrier,
        trackingNumber,
        data: result,
        message: `Shipment tracked successfully via ${normalizedCarrier}`,
      });
    } catch (error) {
      const duration = Date.now() - startTime;
      console.error("[trackShipment] Error occurred", {
        error: error.message,
        stack: error.stack,
        carrier,
        trackingNumber,
        duration: `${duration}ms`,
        timestamp: new Date().toISOString(),
      });
      req.error(500, `Failed to track shipment: ${error.message}`);
    }
  });

  /**
   * Track shipment from items array (auto-detect carrier from description)
   */
  this.on("trackShipmentFromItems", async (req) => {
    const startTime = Date.now();
    const { items } = req.data;

    console.log("[trackShipmentFromItems] Request received", {
      timestamp: new Date().toISOString(),
      itemsProvided: !!items,
    });

    if (!items) {
      req.error(400, "Items data is required");
      return;
    }

    try {
      let itemsArray;
      try {
        itemsArray = typeof items === "string" ? JSON.parse(items) : items;
      } catch (parseError) {
        req.error(400, "Invalid JSON format for items");
        return;
      }

      if (!Array.isArray(itemsArray)) {
        req.error(400, "Items must be an array");
        return;
      }

      console.log("[trackShipmentFromItems] Processing items", {
        itemCount: itemsArray.length,
        items: itemsArray,
      });

      const trackingResults = [];

      for (const item of itemsArray) {
        const { Material, Description } = item;

        if (!Description) {
          console.log(
            "[trackShipmentFromItems] Skipping item without description",
            { Material },
          );
          continue;
        }

        // Detect carrier from description
        const description = Description.toUpperCase();
        let carrier = null;
        let trackingNumber = Material; // Assuming Material contains tracking number

        if (description.includes("DHL")) {
          carrier = "DHL";
        } else if (
          description.includes("FEDEX") ||
          description.includes("FED EX")
        ) {
          carrier = "FEDEX";
        }

        if (!carrier) {
          console.log(
            "[trackShipmentFromItems] No carrier detected in description",
            {
              Material,
              Description,
            },
          );
          trackingResults.push({
            trackingNumber,
            carrier: "UNKNOWN",
            status: "skipped",
            message: "No supported carrier detected in description",
          });
          continue;
        }

        console.log("[trackShipmentFromItems] Tracking shipment", {
          carrier,
          trackingNumber,
          originalDescription: Description,
        });

        try {
          let trackingData;

          if (carrier === "DHL") {
            trackingData = await trackDHL(trackingNumber);
          } else if (carrier === "FEDEX") {
            trackingData = await trackFedEx(trackingNumber);
          }

          trackingResults.push({
            trackingNumber,
            carrier,
            status: "success",
            data: trackingData,
            message: "Shipment tracked successfully",
          });

          console.log("[trackShipmentFromItems] Successfully tracked", {
            carrier,
            trackingNumber,
          });
        } catch (trackError) {
          console.error("[trackShipmentFromItems] Error tracking shipment", {
            error: trackError.message,
            carrier,
            trackingNumber,
          });

          trackingResults.push({
            trackingNumber,
            carrier,
            status: "error",
            message: trackError.message,
          });
        }
      }

      const duration = Date.now() - startTime;
      console.log("[trackShipmentFromItems] Completed processing", {
        totalItems: itemsArray.length,
        trackedItems: trackingResults.length,
        duration: `${duration}ms`,
        timestamp: new Date().toISOString(),
      });

      return JSON.stringify({
        success: true,
        totalItems: itemsArray.length,
        trackedItems: trackingResults.length,
        results: trackingResults,
        message: "Items processed successfully",
      });
    } catch (error) {
      const duration = Date.now() - startTime;
      console.error("[trackShipmentFromItems] Error occurred", {
        error: error.message,
        stack: error.stack,
        duration: `${duration}ms`,
        timestamp: new Date().toISOString(),
      });
      req.error(500, `Failed to process items: ${error.message}`);
    }
  });
};

/**
 * Track shipment via DHL API
 */
async function trackDHL(trackingNumber) {
  console.log("[trackDHL] Tracking shipment", { trackingNumber });

  const axios = require("axios");
  const apiKey = process.env.DHL_API_KEY || "JYL8zk5VSvH6MMsLYfXyLc4JCxOIzTBe";
  const apiUrl =
    process.env.DHL_API_URL || "https://api-eu.dhl.com/track/shipments";

  const url = `${apiUrl}?trackingNumber=${encodeURIComponent(trackingNumber)}`;

  try {
    const response = await axios.get(url, {
      headers: {
        "DHL-API-Key": apiKey,
        Accept: "application/json",
      },
      timeout: 30000,
    });

    console.log("[trackDHL] Successfully retrieved tracking data", {
      trackingNumber,
      hasShipments: !!response.data.shipments,
    });

    return response.data;
  } catch (error) {
    console.error("[trackDHL] Error", {
      error: error.message,
      trackingNumber,
      status: error.response?.status,
      statusText: error.response?.statusText,
    });
    throw new Error(`Failed to track DHL shipment: ${error.message}`);
  }
}

/**
 * Track shipment via FedEx API
 */
async function trackFedEx(trackingNumber) {
  console.log("[trackFedEx] Tracking shipment", { trackingNumber });

  const axios = require("axios");
  const clientId = process.env.FEDEX_CLIENT_ID;
  const clientSecret = process.env.FEDEX_CLIENT_SECRET;
  const apiUrl = process.env.FEDEX_API_URL || "https://apis-sandbox.fedex.com";

  if (!clientId || !clientSecret) {
    throw new Error(
      "FedEx API credentials not configured. Set FEDEX_CLIENT_ID and FEDEX_CLIENT_SECRET environment variables.",
    );
  }

  try {
    // Step 1: Get OAuth token
    const formBody = `grant_type=client_credentials&client_id=${encodeURIComponent(clientId)}&client_secret=${encodeURIComponent(clientSecret)}`;

    const tokenResponse = await axios.post(`${apiUrl}/oauth/token`, formBody, {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      timeout: 30000,
    });

    const accessToken = tokenResponse.data.access_token;
    console.log("[trackFedEx] OAuth token obtained");

    // Step 2: Track shipment
    const trackResponse = await axios.post(
      `${apiUrl}/track/v1/trackingnumbers`,
      {
        includeDetailedScans: true,
        trackingInfo: [
          {
            trackingNumberInfo: {
              trackingNumber: trackingNumber,
            },
          },
        ],
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
          "X-locale": "en_US",
        },
        timeout: 30000,
      },
    );

    console.log("[trackFedEx] Successfully retrieved tracking data", {
      trackingNumber,
      hasResults: !!trackResponse.data.output,
    });

    return trackResponse.data;
  } catch (error) {
    console.error("[trackFedEx] Error", {
      error: error.message,
      trackingNumber,
      status: error.response?.status,
      data: error.response?.data,
    });
    throw new Error(`Failed to track FedEx shipment: ${error.message}`);
  }
}
