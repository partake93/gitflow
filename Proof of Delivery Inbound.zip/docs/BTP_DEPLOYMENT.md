# SAP BTP Deployment Guide

## Prerequisites

1. **Cloud Foundry CLI**: Install from https://github.com/cloudfoundry/cli
2. **Cloud MTA Build Tool**: Install with `npm install -g mbt`
3. **MultiApps CF CLI Plugin**: Install with `cf install-plugin multiapps`
4. **SAP BTP Account**: With Cloud Foundry environment enabled

## Configuration Steps

### 1. Update MTA Configuration

Edit `mta.yaml` and replace placeholders:

```yaml
tokenServiceURL: https://login.microsoftonline.com/<YOUR_TENANT_ID>/oauth2/v2.0/token
clientId: <YOUR_CLIENT_ID>
clientSecret: <YOUR_CLIENT_SECRET>
```

Replace with your actual Azure AD credentials from `.env` file:

- `<YOUR_TENANT_ID>`: cbdd039e-153c-4862-98c6-d61111a86e63
- `<YOUR_CLIENT_ID>`: 7861ed14-2728-4289-a348-0153693e6912
- `<YOUR_CLIENT_SECRET>`: Voe8Q~wbguMyf6DJDw~CobtghyEMYV9iSVyP1cW7

### 2. Login to Cloud Foundry

```bash
# Login to SAP BTP
cf login -a <api-endpoint>

# Example for EU10:
cf login -a https://api.cf.eu10.hana.ondemand.com

# Select your org and space when prompted
```

### 3. Build the MTA Archive

```bash
# Build the MTA archive
mbt build

# This creates: mta_archives/sales-order_1.0.0.mtar
```

### 4. Deploy to SAP BTP

```bash
# Deploy the application
cf deploy mta_archives/sales-order_1.0.0.mtar

# Or use npm script
npm run deploy
```

### 5. Verify Deployment

```bash
# Check deployed applications
cf apps

# Check services
cf services

# Check logs
cf logs inbound-date-srv --recent
```

## Post-Deployment

### Access the Application

After deployment, get the application URL:

```bash
cf apps
```

Look for `inbound-date-srv` and note its URL, e.g.:
`https://inbound-date-srv.cfapps.eu10.hana.ondemand.com`

### Test the API

```bash
# Test catalog service
curl https://inbound-date-srv.cfapps.eu10.hana.ondemand.com/odata/v4/catalog

# Test email service
curl -X POST https://inbound-date-srv.cfapps.eu10.hana.ondemand.com/odata/v4/catalog/getEmailsFromDestination \
  -H "Content-Type: application/json" \
  -d '{"userEmail": "user@domain.com", "maxMessages": 10}'
```

### Configure Destination Service

If you need to update the destination after deployment:

1. Go to SAP BTP Cockpit
2. Navigate to your subaccount
3. Go to Connectivity → Destinations
4. Find or create `MS_GRAPH_API` destination
5. Configure with your Microsoft Graph credentials

## Troubleshooting

### View Application Logs

```bash
# Real-time logs
cf logs inbound-date-srv

# Recent logs
cf logs inbound-date-srv --recent
```

### Restart Application

```bash
cf restart inbound-date-srv
```

### Redeploy

```bash
# Rebuild and redeploy
npm run build
cf deploy mta_archives/sales-order_1.0.0.mtar
```

### Undeploy

```bash
# Remove application and services
npm run undeploy

# Or manually
cf undeploy inbound-date --delete-services
```

## Environment Variables

To set environment variables in BTP:

```bash
cf set-env inbound-date-srv VARIABLE_NAME "value"
cf restage inbound-date-srv
```

## Database Migration

If you need to switch from SQLite to HANA:

1. The `mta.yaml` already configures HANA Cloud HDI container
2. Update your `db/schema.cds` for HANA-specific features if needed
3. Deploy will automatically provision HANA and deploy schema

## Security

### Assign Roles to Users

1. Go to SAP BTP Cockpit
2. Navigate to Security → Role Collections
3. Find `SalesOrderAdmin` or `SalesOrderUser`
4. Assign to users/user groups

## CI/CD Integration

For automated deployment:

```yaml
# Example GitHub Actions workflow
- name: Build MTA
  run: mbt build

- name: Deploy to BTP
  run: cf deploy mta_archives/sales-order_1.0.0.mtar
  env:
    CF_API: ${{ secrets.CF_API }}
    CF_USER: ${{ secrets.CF_USER }}
    CF_PASSWORD: ${{ secrets.CF_PASSWORD }}
    CF_ORG: ${{ secrets.CF_ORG }}
    CF_SPACE: ${{ secrets.CF_SPACE }}
```

## Monitoring

### Application Logs

Access via BTP Cockpit:

1. Go to Cloud Foundry → Spaces → [Your Space]
2. Click on `inbound-date-srv`
3. View Logs tab

### Metrics

View application metrics in BTP Cockpit under monitoring section.

## Support

For issues:

1. Check application logs: `cf logs inbound-date-srv --recent`
2. Verify service bindings: `cf env inbound-date-srv`
3. Check service status: `cf services`
