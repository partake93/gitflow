const axios = require("axios");
const { PDFParse } = require("pdf-parse");
const { jsonrepair } = require("jsonrepair");
const fs = require("fs").promises;

async function analyzePrompt(fileData) {
  try {
    console.log("analyzePrompt called with data type:", typeof fileData);
    console.log("Data length:", fileData?.length || 0);

    const pdfText = await extractPdfText(fileData);
    console.log("Extracted PDF Text:", pdfText.substring(0, 200) + "...");
    // Get access token
    const tokenResponse = await axios.post(
      `${process.env.AICORE_AUTH_URL}/oauth/token/`,
      new URLSearchParams({ grant_type: "client_credentials" }),
      {
        auth: {
          username: process.env.AICORE_CLIENT_ID,
          password: process.env.AICORE_CLIENT_SECRET,
        },
      },
    );

    const accessToken = tokenResponse.data.access_token;

    const headers = {
      "Content-Type": "application/json",
      Accept: "application/json",
      "AI-Resource-Group": process.env.AICORE_RESOURCE_GROUP,
      Authorization: `Bearer ${accessToken}`,
    };

    const systemPrompt = `
            You are an AI assistant that extracts structured data from purchase order PDF files. The input will be the text content of a PDF file. You must carefully parse and extract information across multiple pages.

            ### Extraction Rules:
            - Identify header-level fields:
            - PO Number
            - Date
            - Contact Person
            - Deliver to
            - Terms of delivery
            - Terms of payment
            - Currency
            - Delivery Date
            - HAWB No.
            - MAWB No.
            - Freight Forwarder (CRITICAL PRIORITY: This field is MANDATORY. Look in these locations:
              * Company name near MAWB/HAWB numbers (e.g., "DHL", "FedEx", "UPS", "Aramex")
              * Text following "Issued by" or "Carrier:" labels
              * Prominent company branding/logos in document header
              * Shipping company name at top of air waybill
              * Examples: "DHL", "DHL Express", "FedEx", "UPS", "Aramex", "Blue Dart"
              * If you see any logistics/shipping company name, extract it here)

            - Identify item-level fields (may span multiple rows/pages):
            - Item
            - Material
            - Description
            - Order Quantity
            - Unit
            - Delivery Date
            - Rate.Cond
            - Rate Unit
            - Cond. Price Unit
            - Cond.Value
            - Cond.Unit

            ### Output Format:
            Return only valid JSON in the following schema:
            {
            "header": {
                "PONumber": "",
                "Date": "",
                "ContactPerson": "",
                "DeliverTo": "",
                "TermsOfDelivery": "",
                "TermsOfPayment": "",
                "Currency": "",
                "DeliveryDate":"",
                "HAWBNo": "",
                "MAWBNo": "",
                "FreightForwarder": ""
            },
            "items": [
                {
                "Item": "",
                "Material": "",
                "Description": "",
                "OrderQuantity": "",
                "Unit": "",
                "DeliveryDate": "",
                "RateCond": "",
                "RateUnit": "",
                "CondPriceUnit":"",
                "CondValue": "",
                "CondUnit": ""
                }
            ]
            }

            ### Constraints:
            - Always return a JSON object exactly in the schema above.
            - **CRITICAL: You MUST include ALL header fields in your response, including FreightForwarder, even if empty.**
            - If a field is missing, return an empty string ("").
            - Do not include extra text, explanations, or formatting outside the JSON.
            - Handle multi-page documents by aggregating all items.

            ### Important Notes:
            - Ensure each value maps exactly to its field.
            - RateCond: numeric rate only (e.g., 12.40), no currency/unit symbols.
            - RateUnit: only unit/currency (e.g., USD 1 TON).
            - CondValue: numeric value only (strip $ or symbols).
            - CondUnit: only the unit text (e.g., TON, KG), leave empty if not present.
            - Description: must only contain the product description.
            - FreightForwarder: **MANDATORY FIELD** - Extract the shipping/logistics company name. Look for:
              * Company name appearing near MAWB No. or HAWB No.
              * "Issued by [Company Name]" text
              * Prominent carrier branding (DHL, FedEx, UPS, Aramex, Blue Dart, etc.)
              * Shipping company name in air waybill header
              * DO NOT leave this field empty if any carrier/logistics company name is visible
            - HAWBNo: House Air Waybill number (look for "HAWB No:", "House AWB", etc.)
            - MAWBNo: Master Air Waybill number (look for "MAWB No:", "Master AWB", etc.)
            - If a value cannot be found, leave it as "".
            - Do not merge multiple columns into a single field.
            - Preserve the order of items as in the PDF.

            ---

            ### Input File (Base64 PDF):
            ${pdfText}
            `;

    const payload = {
      messages: [
        {
          role: "user",
          content: systemPrompt,
        },
      ],
      temperature: 0.0,
      frequency_penalty: 0.4,
      presence_penalty: 0.4,
    };

    const postUri = `${process.env.AICORE_BASE_URL}/inference/deployments/d9c086d6b59f2e43/chat/completions?api-version=2023-05-15`;

    let aiResponse = await axios.post(postUri, payload, { headers });

    let rPODetails = aiResponse.data.choices?.[0]?.message?.content || "";

    // Clean JSON string
    rPODetails = cleanJsonString(rPODetails);

    // Parse and return as object instead of string
    try {
      const parsedJson = JSON.parse(rPODetails);
      return parsedJson;
    } catch (parseError) {
      console.error("Failed to parse AI response as JSON:", parseError.message);
      console.error("Raw response:", rPODetails);
      return rPODetails; // Return as string if parsing fails
    }
  } catch (error) {
    console.error("AI call failed:", error.message);
    throw new Error("AI service error");
  }
}

async function analyzePromptGPT5Nano(fileData) {
  try {
    console.log(
      "analyzePromptGPT5Nano called with data type:",
      typeof fileData,
    );
    console.log("Data length:", fileData?.length || 0);

    const pdfText = await extractPdfText(fileData);
    console.log("Extracted PDF Text:", pdfText.substring(0, 200) + "...");

    // Get access token for SAESL AI Core (GPT-5-nano)
    const tokenResponse = await axios.post(
      `${process.env.SAESL_AICORE_AUTH_URL}/oauth/token/`,
      new URLSearchParams({ grant_type: "client_credentials" }),
      {
        auth: {
          username: process.env.SAESL_AICORE_CLIENT_ID,
          password: process.env.SAESL_AICORE_CLIENT_SECRET,
        },
      },
    );

    const accessToken = tokenResponse.data.access_token;

    const headers = {
      "Content-Type": "application/json",
      Accept: "application/json",
      "AI-Resource-Group": process.env.SAESL_AICORE_RESOURCE_GROUP,
      Authorization: `Bearer ${accessToken}`,
    };

    const systemPrompt = `
You are an AI assistant that extracts structured data from purchase order PDF files. The input will be the text content of a PDF file. You must carefully parse and extract information across multiple pages.

### Extraction Rules:
- Identify header-level fields:
  - PO Number
  - Date
  - Contact Person
  - Deliver to
  - Terms of delivery
  - Terms of payment
  - Currency
  - Delivery Date
  - HAWB No.
  - MAWB No.
  - Freight Forwarder (CRITICAL PRIORITY: This field is MANDATORY. Look in these locations:
    * Text containing "Issued by" followed by company name (e.g., "Issued by\nDHL GLOBAL FORWARDING")
    * Text containing "DHL GLOBAL FORWARDING", "DHL COALVILLE DISTRIBUTION", or similar - extract "DHL"
    * Company name near MAWB/HAWB numbers (e.g., "DHL", "FedEx", "UPS", "Aramex")
    * Text following "Carrier:" labels
    * Shipping company name at top of air waybill
    * Examples: "DHL", "DHL Express", "FedEx", "UPS", "Aramex", "Blue Dart"
    * RULE: If you see "DHL" anywhere in company name (like "DHL GLOBAL FORWARDING UK LTD"), extract just "DHL"
    * If you see any logistics/shipping company name, extract it here)

- Identify item-level fields (may span multiple rows/pages):
  - Item
  - Material
  - Description
  - Order Quantity
  - Unit
  - Delivery Date
  - Rate.Cond
  - Rate Unit
  - Cond. Price Unit
  - Cond.Value
  - Cond.Unit
  - HAWB No.
  - MAWB No.

- Identify item-level fields (may span multiple rows/pages):
  - Item
  - Material
  - Description
  - Order Quantity
  - Unit
  - Delivery Date
  - Rate.Cond
  - Rate Unit
  - Cond. Price Unit
  - Cond.Value
  - Cond.Unit

### Output Format:
Return only valid JSON in the following schema:
{
  "header": {
    "PONumber": "",
    "Date": "",
    "ContactPerson": "",
    "DeliverTo": "",
    "TermsOfDelivery": "",
    "TermsOfPayment": "",
    "Currency": "",
    "DeliveryDate": "",
    "HAWBNo": "",
    "MAWBNo": "",
    "FreightForwarder": ""
  },
  "items": [
    {
      "Item": "",
      "Material": "",
      "Description": "",
      "OrderQuantity": "",
      "Unit": "",
      "DeliveryDate": "",
      "RateCond": "",
      "RateUnit": "",
      "CondPriceUnit": "",
      "CondValue": "",
      "CondUnit": ""
    }
  ]
}

### Constraints:
- Always return a JSON object exactly in the schema above.
- **CRITICAL: You MUST include ALL header fields in your response, including FreightForwarder, even if empty.**
- If a field is missing, return an empty string ("").
- Do not include extra text, explanations, or formatting outside the JSON.
- Handle multi-page documents by aggregating all items.

### Important Notes:
- Ensure each value maps exactly to its field.
- RateCond: numeric rate only (e.g., 12.40), no currency/unit symbols.
- RateUnit: only unit/currency (e.g., USD 1 TON).
- CondValue: numeric value only (strip $ or symbols).
- CondUnit: only the unit text (e.g., TON, KG), leave empty if not present.
- Description: must only contain the product description.
- FreightForwarder: **MANDATORY FIELD** - Extract the shipping/logistics company name. Look for:
  * "Issued by" text followed by company name (e.g., "Issued by DHL GLOBAL FORWARDING")
  * If you see "DHL" in any company name (like "DHL GLOBAL FORWARDING UK LTD"), extract just "DHL"
  * If you see "FEDEX" in company name, extract "FedEx"
  * Company name appearing near MAWB No. or HAWB No.
  * Prominent carrier branding (DHL, FedEx, UPS, Aramex, Blue Dart, etc.)
  * Shipping company name in air waybill header
  * DO NOT leave this field empty if any carrier/logistics company name is visible
- HAWBNo: House Air Waybill number (look for "HAWB No:", "House AWB", etc.)
- MAWBNo: Master Air Waybill number (look for "MAWB No:", "Master AWB", etc.)
- If a value cannot be found, leave it as "".
- Do not merge multiple columns into a single field.
- Preserve the order of items as in the PDF.

---

### Input File Text Content:
${pdfText}
`;

    const payload = {
      messages: [
        {
          role: "user",
          content: systemPrompt,
        },
      ],
      max_completion_tokens: 16000,
    };

    const postUri = `${process.env.SAESL_AICORE_BASE_URL}/inference/deployments/d16aff623d2acd42/chat/completions?api-version=2023-05-15`;

    console.log("Sending PDF text to GPT-5-nano for extraction...", postUri);
    console.log("PDF text length being sent:", pdfText.length, "characters");

    // Add retry logic and timeout configuration
    let aiResponse;
    const maxRetries = 3;
    let lastError;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`Attempt ${attempt}/${maxRetries} to call GPT-5-nano...`);
        aiResponse = await axios.post(postUri, payload, {
          headers,
          timeout: 120000, // 120 second timeout
          maxContentLength: Infinity,
          maxBodyLength: Infinity,
        });
        console.log("GPT-5-nano response received successfully");
        break; // Success, exit retry loop
      } catch (error) {
        lastError = error;
        console.error(`Attempt ${attempt} failed:`, error.message);
        if (
          attempt < maxRetries &&
          (error.code === "ECONNRESET" || error.code === "ETIMEDOUT")
        ) {
          const waitTime = attempt * 2000; // Progressive backoff: 2s, 4s, 6s
          console.log(`Retrying in ${waitTime}ms...`);
          await new Promise((resolve) => setTimeout(resolve, waitTime));
        } else {
          throw lastError;
        }
      }
    }

    let rPODetails = aiResponse.data.choices?.[0]?.message?.content || "";

    // Clean JSON string
    rPODetails = cleanJsonString(rPODetails);

    // Parse and return as object instead of string
    try {
      const parsedJson = JSON.parse(rPODetails);
      console.log(parsedJson);
      return parsedJson;
    } catch (parseError) {
      console.error("Failed to parse AI response as JSON:", parseError.message);
      console.error("Raw response:", rPODetails);
      return rPODetails; // Return as string if parsing fails
    }
  } catch (error) {
    console.error("GPT-5-nano AI call failed:", error.message);
    if (error.response) {
      console.error("Error status:", error.response.status);
      console.error(
        "Error data:",
        JSON.stringify(error.response.data, null, 2),
      );
    }
    throw new Error("GPT-5-nano AI service error");
  }
}

function cleanJsonString(str) {
  // Remove markdown code blocks if present
  str = str.replace(/```json\s*/g, "").replace(/```\s*/g, "");

  // Try to extract JSON object from the string
  const jsonMatch = str.match(/\{[\s\S]*\}/);
  if (jsonMatch) {
    str = jsonMatch[0];
  }

  return (
    str
      .trim()
      // Remove markdown bold/italic formatting: **"key"** or *'key'*
      .replace(/\*\*"([^"]+)"\*\*/g, '"$1"')
      .replace(/\*\*'([^']+)'\*\*/g, '"$1"')
      .replace(/\*"([^"]+)"\*/g, '"$1"')
      .replace(/\*'([^']+)'\*/g, '"$1"')
      // Replace # used as quote character with "
      .replace(/#([^#:,}]+)#/g, '"$1"')
      // Replace = with : when used as key-value separator
      .replace(/"\s*=\s*"/g, '":"')
      .replace(/"\s*=\s*/g, '":')
      // Remove outer quotes if present
      .replace(/^'(.*)'$/, "$1")
      .replace(/^"(.*)"$/, "$1")
      // Convert ALL smart quotes and quote variants to normal quotes
      .replace(/[""„‟]/g, '"') // Standard smart quotes + German quotes
      .replace(/[''‚‛]/g, "'") // Smart single quotes + variants
      .replace(/[«»‹›]/g, '"') // Guillemets
      // Normalize tripled or more quotes (but preserve empty strings "")
      .replace(/"{3,}/g, '"')
      .replace(/'{3,}/g, '"')
      // Strip obvious junk separators
      .replace(/[;,]+/g, ",")
      .replace(/,{2,}/g, ",")
      // Convert single-quoted keys/values to double-quoted JSON style
      .replace(/'\s*([A-Za-z][A-Za-z\s]*)\s*'\s*:/g, '"$1":')
      .replace(/:\s*'([^']*)'/g, ':"$1"')
      // Strip spaces inside date values (e.g., "13 /02 /2026" -> "13/02/2026")
      .replace(/"(\d+)\s*\/\s*(\d+)\s*\/\s*(\d+)"/g, '"$1/$2/$3"')
      .replace(/"(\d+)\s*-\s*(\d+)\s*-\s*(\d+)"/g, '"$1-$2-$3"')
      // Ensure valid JSON structure (remove trailing commas)
      .replace(/,\s*}/g, "}")
      .replace(/,\s*]/g, "]")
      // Normalize common key variants and spacing
      .replace(/"\s*Item\s*"/gi, '"Item"')
      .replace(/"\s*Material\s*"/gi, '"Material"')
      .replace(/"\s*Description\s*"/gi, '"Description"')
      .replace(/"\s*Order\s*Quantity\s*"/gi, '"OrderQuantity"')
      .replace(/"\s*OrderQuantity\s*"/gi, '"OrderQuantity"')
      .replace(/"\s*Unit\s*"/gi, '"Unit"')
      .replace(/"\s*Delivery\s*Date\s*"/gi, '"DeliveryDate"')
      .replace(/"\s*DeliveryDate\s*"/gi, '"DeliveryDate"')
      .replace(/"\s*Rate\s*Cond(?:ition)?\s*"/gi, '"RateCond"')
      .replace(/"\s*RateCond\s*"/gi, '"RateCond"')
      .replace(/"\s*Rate\s*Unit\s*"/gi, '"RateUnit"')
      .replace(/"\s*RateUnit\s*"/gi, '"RateUnit"')
      .replace(/"\s*Cond\s*Price\s*Unit\s*"/gi, '"CondPriceUnit"')
      .replace(/"\s*CondPriceUnit\s*"/gi, '"CondPriceUnit"')
      .replace(/"\s*Cond\s*Value\s*"/gi, '"CondValue"')
      .replace(/"\s*CondValue\s*"/gi, '"CondValue"')
      .replace(/"\s*Cond\s*Unit\s*"/gi, '"CondUnit"')
      .replace(/"\s*CondUnit\s*"/gi, '"CondUnit"')
  );
}

function repairIncompleteJson(str) {
  // Fix unquoted or partially quoted property names (e.g., ateCond": -> "ateCond":)
  // Match patterns like:  \n  SomeText": "value"  and add opening quote
  str = str.replace(/([,\[\{]\s*)([A-Za-z][A-Za-z0-9]*)":\s*/g, '$1"$2":');

  // Fix known truncated property names
  str = str.replace(/"ateCond":/gi, '"RateCond":');
  str = str.replace(/"aterial":/gi, '"Material":');
  str = str.replace(/"escription":/gi, '"Description":');
  str = str.replace(/"eliveryDate":/gi, '"DeliveryDate":');
  str = str.replace(/"rderQuantity":/gi, '"OrderQuantity":');
  str = str.replace(/"ateUnit":/gi, '"RateUnit":');
  str = str.replace(/"ondPriceUnit":/gi, '"CondPriceUnit":');
  str = str.replace(/"ondValue":/gi, '"CondValue":');
  str = str.replace(/"ondUnit":/gi, '"CondUnit":');

  // Fix single-letter truncations (severely truncated property names)
  // Look for pattern: previous known property, then single letter
  str = str.replace(
    /"OrderQuantity"\s*:\s*"[^"]*"\s*,\s*"m":/gi,
    '"OrderQuantity":"","Unit":',
  );
  str = str.replace(
    /"Unit"\s*:\s*"[^"]*"\s*,\s*"t":/gi,
    '"Unit":"","DeliveryDate":',
  );
  str = str.replace(
    /"DeliveryDate"\s*:\s*"[^"]*"\s*,\s*"d":/gi,
    '"DeliveryDate":"","RateCond":',
  );
  str = str.replace(
    /"RateCond"\s*:\s*"[^"]*"\s*,\s*"t":/gi,
    '"RateCond":"","RateUnit":',
  );
  str = str.replace(
    /"RateUnit"\s*:\s*"[^"]*"\s*,\s*"t":/gi,
    '"RateUnit":"","CondPriceUnit":',
  );
  str = str.replace(
    /"CondPriceUnit"\s*:\s*"[^"]*"\s*,\s*"e":/gi,
    '"CondPriceUnit":"","CondValue":',
  );
  str = str.replace(
    /"CondValue"\s*:\s*"[^"]*"\s*,\s*"t":/gi,
    '"CondValue":"","CondUnit":',
  );

  // Check if JSON is incomplete
  const openBraces = (str.match(/\{/g) || []).length;
  const closeBraces = (str.match(/\}/g) || []).length;
  const openBrackets = (str.match(/\[/g) || []).length;
  const closeBrackets = (str.match(/\]/g) || []).length;

  // Count open quotes (should be even)
  const quotes = (str.match(/"/g) || []).length;

  // If odd number of quotes, we have an unclosed string - close it
  if (quotes % 2 !== 0) {
    str += '"';
  }

  // If ends with incomplete key-value pair like "Material":"91
  // Complete the value and close properly
  if (str.match(/:\s*"[^"]*$/)) {
    str += '"';
  }

  // Remove trailing comma if present
  str = str.replace(/,\s*$/, "");

  // Close any unclosed arrays
  for (let i = 0; i < openBrackets - closeBrackets; i++) {
    str += "]";
  }

  // Close any unclosed objects
  for (let i = 0; i < openBraces - closeBraces; i++) {
    str += "}";
  }

  return str;
}

function normalizeItemsSchema(data) {
  if (!data || !Array.isArray(data.items)) {
    return data;
  }

  const normalizeValue = (value) => {
    if (value === null || value === undefined) return "";
    return String(value).trim();
  };

  data.items = data.items.map((item) => ({
    PO: normalizeValue(item.PO || item.po),
    Material: normalizeValue(item.Material || item.material),
    Description: normalizeValue(item.Description || item.description),
    DeliveryDate: normalizeValue(item.DeliveryDate || item.deliverydate),
    RateCond: normalizeValue(item.RateCond || item.ratecond),
  }));

  return data;
}

async function extractPdfText(fileDataBase64) {
  try {
    console.log("Starting PDF extraction...");
    console.log("Base64 length:", fileDataBase64?.length || 0);

    const pdfBuffer = Buffer.from(fileDataBase64, "base64");
    console.log("Buffer created, size:", pdfBuffer.length, "bytes");

    const parser = new PDFParse({ data: pdfBuffer });
    const result = await parser.getText();
    console.log(
      "PDF parsed successfully, text length:",
      result.text?.length || 0,
    );

    // Log full extracted text for debugging
    console.log("=== FULL EXTRACTED PDF TEXT ===");
    console.log(result.text);
    console.log("=== END OF EXTRACTED PDF TEXT ===");

    // Check specifically for freight forwarder keywords
    const freightKeywords = [
      "DHL",
      "FedEx",
      "UPS",
      "Aramex",
      "Issued by",
      "Carrier",
    ];
    const foundKeywords = freightKeywords.filter((keyword) =>
      result.text.toUpperCase().includes(keyword.toUpperCase()),
    );
    console.log(
      "Freight forwarder keywords found in PDF:",
      foundKeywords.length > 0 ? foundKeywords : "NONE",
    );

    return result.text;
  } catch (err) {
    console.error("PDF parsing failed - Full error:", err);
    console.error("Error message:", err.message);
    console.error("Error stack:", err.stack);
    throw new Error(`Could not extract text from PDF: ${err.message}`);
  }
}

async function analyzeImagePrompt(imageDataBase64) {
  try {
    console.log("analyzeImagePrompt called with image data");
    console.log("Base64 image data length:", imageDataBase64?.length || 0);

    // Get access token
    const tokenResponse = await axios.post(
      `${process.env.SAESL_AICORE_AUTH_URL}/oauth/token/`,
      new URLSearchParams({ grant_type: "client_credentials" }),
      {
        auth: {
          username: process.env.SAESL_AICORE_CLIENT_ID,
          password: process.env.SAESL_AICORE_CLIENT_SECRET,
        },
      },
    );

    const accessToken = tokenResponse.data.access_token;

    const headers = {
      "Content-Type": "application/json",
      Accept: "application/json",
      "AI-Resource-Group": process.env.SAESL_AICORE_RESOURCE_GROUP,
      Authorization: `Bearer ${accessToken}`,
    };

    const systemPrompt = `
You are an AI assistant that extracts structured data from images containing EITHER tabular data OR shipping labels.

### IMAGE TYPE 1: TABLE DATA
If the image shows a table with columns like PO, ETA, Inbound Tracking Number, Inbound Logistics Partner, Despatch Date Inbound:

**Column Mapping (MANDATORY - Extract ALL fields):**
- "PO" column → PO
- "Inbound Tracking Number" column → Material  
- "Inbound Logistics Partner" column → Description
- "ETA" column → DeliveryDate (CRITICAL: Extract ANY date you see in this column)
- "Despatch Date Inbound" column → RateCond (CRITICAL: Extract ANY date you see in this column)

**CRITICAL RULES FOR DATES:**
- Look carefully at BOTH the ETA column AND the Despatch Date Inbound column
- If you see ANY date value (like 13-02-2026, 13/02/2026, 7/2/2026, etc.) in the Despatch Date Inbound column, you MUST put it in RateCond
- If you see ANY date value in the ETA column, you MUST put it in DeliveryDate
- NEVER leave RateCond empty if there is a date visible in the Despatch Date Inbound column
- Extract ALL rows from the table
- **IMPORTANT: Convert ALL dates to MM-DD-YYYY format**
  * Examples: "13-02-2026" becomes "02-13-2026", "7/2/2026" becomes "02-07-2026"
  * If you see DD-MM-YYYY or DD/MM/YYYY, convert it to MM-DD-YYYY
  * Always use two digits for month and day (pad with zero if needed)

### IMAGE TYPE 2: SHIPPING LABEL
If the image shows a shipping label (like DHL, FedEx, UPS, etc.) with barcode, tracking number, destination:

**Field Mapping:**
- Housebill/Tracking Number/Barcode text → Material
- Carrier name (DHL, FedEx, UPS, etc.) → Description
- Leave PO, DeliveryDate, RateCond as empty strings

**Instructions:**
- Extract the main tracking number (barcode text or housebill number)
- Identify the carrier/logistics partner from the label
- Return a single item in the items array

### EXAMPLE 1 - Table Row (showing BOTH dates extracted):
{
  "PO": "4000794931",
  "Material": "32619533975",
  "Description": "DHL Express",
  "DeliveryDate": "02-13-2026",
  "RateCond": "02-07-2026"
}

### EXAMPLE 2 - Table Row (only one date available):
{
  "PO": "4000791307",
  "Material": "4944899549",
  "Description": "Aramex",
  "DeliveryDate": "02-13-2026",
  "RateCond": "02-10-2026"
}

### EXAMPLE 3 - Shipping Label:
{
  "PO": "",
  "Material": "8FE7018",
  "Description": "DHL",
  "DeliveryDate": "",
  "RateCond": ""
}

### JSON Output Format (STRICT):
{
  "header": {
    "PONumber": "",
    "Date": "",
    "ContactPerson": "",
    "DeliverTo": "",
    "TermsOfDelivery": "",
    "TermsOfPayment": "",
    "Currency": "",
    "DeliveryDate": "",
    "HAWBNo": "",
    "MAWBNo": "",
    "FreightForwarder": ""
  },
  "items": [
    {
      "PO": "",
      "Material": "",
      "Description": "",
      "DeliveryDate": "",
      "RateCond": ""
    }
  ]
}

### MANDATORY RULES:
- Use ONLY double quotes (")
- Determine if image is a TABLE or SHIPPING LABEL
- For tables: 
  * Extract ALL rows completely
  * Check EVERY row for dates in BOTH the ETA and Despatch Date Inbound columns
  * If Despatch Date Inbound has a date, it MUST go in RateCond field
  * If ETA has a date, it MUST go in DeliveryDate field
  * Do NOT leave RateCond empty if a date exists in Despatch Date Inbound column
  * **Convert ALL dates to MM-DD-YYYY format** (e.g., 13-02-2026 → 02-13-2026)
- For shipping labels: extract tracking number and carrier name
- Use exact key names: PO, Material, Description, DeliveryDate, RateCond
- If a field is not applicable, use empty string ""
- **ALL dates MUST be in MM-DD-YYYY format with zero-padding** (e.g., 02-13-2026, not 2-13-2026)
- Return ONLY the JSON object, no explanations
`;

    const payload = {
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: systemPrompt,
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${imageDataBase64}`,
              },
            },
          ],
        },
      ],
      max_completion_tokens: 16000,
    };

    const postUri = `${process.env.SAESL_AICORE_BASE_URL}/inference/deployments/d16aff623d2acd42/chat/completions?api-version=2023-05-15`;

    console.log("Sending image to AI Core for extraction...", postUri);
    const aiResponse = await axios.post(postUri, payload, { headers });

    let extractedData = aiResponse.data.choices?.[0]?.message?.content || "";
    console.log("AI Core response received, length:", extractedData.length);
    // console.log(
    //   "Raw AI response (first 500 chars):",
    //   extractedData.substring(0, 500),
    // );

    // Clean JSON string
    extractedData = cleanJsonString(extractedData);
    // Apply JSON repair for truncation/incomplete JSON
    extractedData = repairIncompleteJson(extractedData);
    console.log("=== FULL CLEANED JSON RESPONSE ===");
    console.log(extractedData);
    console.log("=== END OF CLEANED JSON ===");

    // Parse and return as object
    try {
      const parsedJson = JSON.parse(extractedData);
      const normalizedJson = normalizeItemsSchema(parsedJson);
      console.log(
        `Extracted ${normalizedJson.items?.length || 0} items from image`,
      );
      return normalizedJson;
    } catch (parseError) {
      console.error("Failed to parse AI response as JSON:", parseError.message);
      console.error("Cleaned response (full):", extractedData);
      // Try to show where the error is
      const errorPos = parseError.message.match(/position (\d+)/);
      if (errorPos) {
        const pos = parseInt(errorPos[1]);
        console.error(
          "Error context:",
          extractedData.substring(Math.max(0, pos - 50), pos + 50),
        );
      }

      // Try using jsonrepair as a last resort
      console.log("Attempting to repair JSON with jsonrepair library...");
      try {
        const repairedJson = jsonrepair(extractedData);
        console.log("JSON repair successful!");
        const parsedJson = JSON.parse(repairedJson);
        const normalizedJson = normalizeItemsSchema(parsedJson);
        console.log(
          `Extracted ${normalizedJson.items?.length || 0} items from image after repair`,
        );
        return normalizedJson;
      } catch (repairError) {
        console.error("JSON repair also failed:", repairError.message);
        return extractedData;
      }
    }
  } catch (error) {
    console.error("AI image extraction failed:", error.message);
    if (error.response) {
      console.error("Error status:", error.response.status);
      console.error(
        "Error data:",
        JSON.stringify(error.response.data, null, 2),
      );
    }
    throw new Error(`AI image extraction error: ${error.message}`);
  }
}

module.exports = { analyzePrompt, analyzePromptGPT5Nano, analyzeImagePrompt };
