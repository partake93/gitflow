const { Client } = require("@microsoft/microsoft-graph-client");
require("isomorphic-fetch");

class SharePointService {
  constructor() {
    this.client = null;
  }

  async authenticate() {
    const axios = require("axios");
    let accessToken;

    try {
      console.log("Authenticating with Azure AD...");
      console.log("Tenant ID:", process.env.SHAREPOINT_TENANT_ID);
      console.log("Client ID:", process.env.SHAREPOINT_CLIENT_ID);

      // Get access token using client credentials flow
      const tokenResponse = await axios.post(
        `https://login.microsoftonline.com/${process.env.SHAREPOINT_TENANT_ID}/oauth2/v2.0/token`,
        new URLSearchParams({
          client_id: process.env.SHAREPOINT_CLIENT_ID,
          client_secret: process.env.SHAREPOINT_CLIENT_SECRET,
          scope: "https://graph.microsoft.com/.default",
          grant_type: "client_credentials",
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        },
      );

      accessToken = tokenResponse.data.access_token;
      console.log("Successfully obtained access token");
    } catch (authError) {
      console.error("Authentication failed:", authError.message);
      if (authError.response) {
        console.error("Auth error status:", authError.response.status);
        console.error(
          "Auth error data:",
          JSON.stringify(authError.response.data, null, 2),
        );
      }
      throw authError;
    }

    // Initialize Graph client
    this.client = Client.init({
      authProvider: (done) => {
        done(null, accessToken);
      },
    });

    return this.client;
  }

  async getFileFromSharePoint(siteUrl, libraryName, fileName) {
    try {
      console.log(`Fetching file: ${fileName} from SharePoint`);
      console.log(`Site: ${siteUrl}`);
      console.log(`Library: ${libraryName}`);

      if (!this.client) {
        await this.authenticate();
      }

      console.log("Authenticated with SharePoint::::::::::::");

      // Extract site path from URL
      const sitePath = new URL(siteUrl).pathname;

      // Get site ID
      const site = await this.client
        .api(`/sites/${process.env.SHAREPOINT_HOST_NAME}:${sitePath}`)
        .get();

      // Extract actual site GUID from composite ID (format: hostname,siteId,webId)
      const siteId = site.id.split(",")[1];
      console.log("Site ID:", siteId);

      // Get drive (document library)
      const drives = await this.client.api(`/sites/${siteId}/drives`).get();

      const targetDrive = drives.value.find(
        (drive) => drive.name === libraryName,
      );

      if (!targetDrive) {
        throw new Error(`Document library '${libraryName}' not found`);
      }

      console.log("Drive ID:", targetDrive.id);

      // Get file content
      const fileContent = await this.client
        .api(`/drives/${targetDrive.id}/root:/SAMPLE PO/${fileName}:/content`)
        .getStream();

      // Convert stream to buffer
      const chunks = [];
      for await (const chunk of fileContent) {
        chunks.push(chunk);
      }
      const buffer = Buffer.concat(chunks);

      console.log(
        "File downloaded successfully, size:",
        buffer.length,
        "bytes",
      );

      return buffer;
    } catch (error) {
      console.error("SharePoint error:", error.message);
      console.error("Error details:", JSON.stringify(error, null, 2));

      if (error.response) {
        console.error("Response status:", error.response.status);
        console.error(
          "Response data:",
          JSON.stringify(error.response.data, null, 2),
        );
      }

      if (error.statusCode) {
        console.error("Graph API status code:", error.statusCode);
      }

      if (error.body) {
        console.error(
          "Graph API error body:",
          JSON.stringify(error.body, null, 2),
        );
      }

      throw error;
    }
  }

  async postFileToSharePoint(
    siteUrl,
    libraryName,
    folderPath,
    fileName,
    fileBuffer,
  ) {
    try {
      console.log(`Uploading file: ${fileName} to SharePoint`);
      console.log(`Site: ${siteUrl}`);
      console.log(`Library: ${libraryName}`);
      console.log(`Folder: ${folderPath}`);
      console.log(`File size: ${fileBuffer.length} bytes`);

      if (!this.client) {
        await this.authenticate();
      }

      console.log("Authenticated with SharePoint");

      // Extract site path from URL
      const sitePath = new URL(siteUrl).pathname;

      // Get site ID
      const site = await this.client
        .api(`/sites/${process.env.SHAREPOINT_HOST_NAME}:${sitePath}`)
        .get();

      // Extract actual site GUID from composite ID (format: hostname,siteId,webId)
      const siteId = site.id.split(",")[1];
      console.log("Site ID:", siteId);

      // Get drive (document library)
      const drives = await this.client.api(`/sites/${siteId}/drives`).get();

      const targetDrive = drives.value.find(
        (drive) => drive.name === libraryName,
      );

      if (!targetDrive) {
        throw new Error(`Document library '${libraryName}' not found`);
      }

      console.log("Drive ID:", targetDrive.id);

      // Construct file path
      const fullPath = folderPath ? `${folderPath}/${fileName}` : fileName;

      console.log("Full path:", fullPath);

      // Upload file using PUT
      const uploadResponse = await this.client
        .api(`/drives/${targetDrive.id}/root:/${fullPath}:/content`)
        .putStream(fileBuffer);

      console.log("File uploaded successfully");
      console.log("File ID:", uploadResponse.id);
      console.log("File web URL:", uploadResponse.webUrl);

      return {
        success: true,
        id: uploadResponse.id,
        name: uploadResponse.name,
        webUrl: uploadResponse.webUrl,
        size: uploadResponse.size,
        createdDateTime: uploadResponse.createdDateTime,
        lastModifiedDateTime: uploadResponse.lastModifiedDateTime,
      };
    } catch (error) {
      console.error("SharePoint upload error:", error.message);
      console.error("Error details:", JSON.stringify(error, null, 2));

      if (error.response) {
        console.error("Response status:", error.response.status);
        console.error(
          "Response data:",
          JSON.stringify(error.response.data, null, 2),
        );
      }

      if (error.statusCode) {
        console.error("Graph API status code:", error.statusCode);
      }

      if (error.body) {
        console.error(
          "Graph API error body:",
          JSON.stringify(error.body, null, 2),
        );
      }

      throw error;
    }
  }

  async listFiles(siteUrl, libraryName, folderPath = "") {
    try {
      if (!this.client) {
        await this.authenticate();
      }

      const sitePath = new URL(siteUrl).pathname;
      const site = await this.client
        .api(`/sites/${process.env.SHAREPOINT_HOST_NAME}:${sitePath}`)
        .get();

      // Extract actual site GUID from composite ID
      const siteId = site.id.split(",")[1];

      const drives = await this.client.api(`/sites/${siteId}/drives`).get();

      const targetDrive = drives.value.find(
        (drive) => drive.name === libraryName,
      );

      if (!targetDrive) {
        throw new Error(`Document library '${libraryName}' not found`);
      }

      const path = folderPath ? `/${folderPath}` : "";
      const items = await this.client
        .api(`/drives/${targetDrive.id}/root:${path}:/children`)
        .get();

      return items.value.map((item) => ({
        name: item.name,
        size: item.size,
        type: item.file ? "file" : "folder",
        lastModified: item.lastModifiedDateTime,
        webUrl: item.webUrl,
      }));
    } catch (error) {
      console.error("SharePoint list error:", error.message);
      throw error;
    }
  }
}

module.exports = new SharePointService();
