const cds = require("@sap/cds");
const xsenv = require("@sap/xsenv");
const axios = require("axios");
const FormData = require("form-data");
const fs = require("fs");
const path = require("path");

const {
  analyzePrompt,
  analyzeImagePrompt,
  analyzePromptGPT5Nano,
} = require("./aiHelper");
const sharepointService = require("./sharepointService");
const outlookService = require("./outlookService");
const workflowService = require("./workflowService");
const documentAIService = require("./documentAIService");
const { getAttachment } = require("./getMail");
const emailService = require("./emailService");
const trackingService = require("./trackingService");
const { exportTrackingEventsSimplified } = require("./excelExportService");

/**
 * Helper function to track shipments from AI analysis result
 */
async function trackShipmentsFromAIResult(aiResult) {
  const startTime = Date.now();
  console.log("[trackShipmentsFromAIResult] Starting shipment tracking", {
    timestamp: new Date().toISOString(),
    hasResult: !!aiResult,
  });

  try {
    // Extract items from AI result
    const items = aiResult?.items || [];

    if (items.length === 0) {
      console.log("[trackShipmentsFromAIResult] No items found in result");
      return {
        success: true,
        trackingResults: [],
        message: "No items to track",
      };
    }

    console.log("[trackShipmentsFromAIResult] Processing items", {
      itemCount: items.length,
    });

    const trackingResults = [];

    for (const item of items) {
      const { Material, Description } = item;

      if (!Description || !Material) {
        console.log(
          "[trackShipmentsFromAIResult] Skipping item - missing data",
          {
            Material,
            Description,
          },
        );
        continue;
      }

      // Detect carrier from description
      const description = Description.toUpperCase();
      let carrier = null;

      if (description.includes("DHL")) {
        carrier = "DHL";
      } else if (
        description.includes("FEDEX") ||
        description.includes("FED EX")
      ) {
        carrier = "FEDEX";
      }

      if (!carrier) {
        console.log("[trackShipmentsFromAIResult] No carrier detected", {
          Material,
          Description,
        });
        trackingResults.push({
          trackingNumber: Material,
          carrier: "UNKNOWN",
          status: "skipped",
          message: "No supported carrier detected in description",
          item: item,
        });
        continue;
      }

      console.log("[trackShipmentsFromAIResult] Tracking shipment", {
        carrier,
        trackingNumber: Material,
        description: Description,
      });

      try {
        let trackingData;

        if (carrier === "DHL") {
          trackingData = await trackDHL("I200180");
        } else if (carrier === "FEDEX") {
          trackingData = await trackFedEx(Material);
        }

        // console.log(
        //   "[trackShipmentsFromAIResult] Full tracking data:",
        //   JSON.stringify(trackingData, null, 2),
        // );

        // Check for delivery status
        let deliveryStatus = null;
        let deliveryDate = null;
        let deliveryLocation = null;

        if (carrier === "DHL" && trackingData.shipments) {
          trackingData.shipments.forEach((shipment) => {
            if (shipment.events && Array.isArray(shipment.events)) {
              const deliveredEvent = shipment.events.find((event) =>
                (event.description || "")
                  .toLowerCase()
                  .includes("shipment delivered"),
              );

              if (deliveredEvent) {
                deliveryStatus = "delivered";
                deliveryDate = deliveredEvent.timestamp;
                deliveryLocation =
                  deliveredEvent.location?.address?.addressLocality || "N/A";
              }
            }
          });
        } else if (carrier === "FEDEX" && trackingData.output) {
          const trackResults = trackingData.output.completeTrackResults || [];
          trackResults.forEach((track) => {
            if (track.trackResults && track.trackResults[0]?.scanEvents) {
              const deliveredEvent = track.trackResults[0].scanEvents.find(
                (event) =>
                  (event.eventDescription || "")
                    .toLowerCase()
                    .includes("delivered"),
              );

              if (deliveredEvent) {
                deliveryStatus = "delivered";
                deliveryDate = deliveredEvent.date;
                deliveryLocation = deliveredEvent.scanLocation?.city || "N/A";
              }
            }
          });
        }

        if (!deliveryStatus) {
          deliveryStatus = "in_transit";
        }

        trackingResults.push({
          trackingNumber: Material,
          carrier,
          status: "success",
          trackingData,
          deliveryStatus: deliveryStatus,
          deliveryDate: deliveryDate,
          deliveryLocation: deliveryLocation,
          message: "Shipment tracked successfully",
          item: item,
        });
        // console.log(
        //   "[trackShipmentsFromAIResult] Full tracking results:",
        //   JSON.stringify(trackingResults, null, 2),
        // );
        console.log("[trackShipmentsFromAIResult] Successfully tracked", {
          carrier,
          trackingNumber: Material,
          deliveryStatus,
          deliveryDate,
          deliveryLocation,
        });
      } catch (trackError) {
        console.error("[trackShipmentsFromAIResult] Error tracking shipment", {
          error: trackError.message,
          carrier,
          trackingNumber: Material,
        });

        trackingResults.push({
          trackingNumber: Material,
          carrier,
          status: "error",
          message: trackError.message,
          item: item,
        });
      }
    }

    const duration = Date.now() - startTime;
    console.log("[trackShipmentsFromAIResult] Completed tracking", {
      totalItems: items.length,
      trackingResults: trackingResults,
      trackedItems: trackingResults.length,
      successCount: trackingResults.filter((r) => r.status === "success")
        .length,
      errorCount: trackingResults.filter((r) => r.status === "error").length,
      skippedCount: trackingResults.filter((r) => r.status === "skipped")
        .length,
      duration: `${duration}ms`,
      timestamp: new Date().toISOString(),
    });

    // Export tracking events to Excel
    let excelFilePath = null;
    let sharepointUploadResult = null;
    const successfulTracking = trackingResults.filter(
      (r) => r.status === "success" && r.trackingData,
    );
    if (successfulTracking.length > 0) {
      try {
        excelFilePath = exportTrackingEventsSimplified(successfulTracking);
        console.log("[trackShipmentsFromAIResult] Excel file created", {
          filePath: excelFilePath,
        });

        // Upload Excel file to SharePoint
        if (excelFilePath && process.env.SHAREPOINT_SITE_URL) {
          try {
            console.log(
              "[trackShipmentsFromAIResult] Uploading Excel to SharePoint",
              {
                timestamp: new Date().toISOString(),
              },
            );

            // Read the Excel file
            const fileBuffer = fs.readFileSync(excelFilePath);
            const fileName = path.basename(excelFilePath);

            // Upload to SharePoint
            sharepointUploadResult =
              await sharepointService.postFileToSharePoint(
                process.env.SHAREPOINT_SITE_URL,
                process.env.SHAREPOINT_LIBRARY_NAME || "Documents",
                process.env.SHAREPOINT_FOLDER_PATH || "Tracking Reports",
                fileName,
                fileBuffer,
              );

            console.log(
              "[trackShipmentsFromAIResult] Excel uploaded to SharePoint",
              {
                webUrl: sharepointUploadResult.webUrl,
                fileId: sharepointUploadResult.id,
              },
            );
          } catch (uploadError) {
            console.error(
              "[trackShipmentsFromAIResult] Failed to upload Excel to SharePoint",
              {
                error: uploadError.message,
                stack: uploadError.stack,
              },
            );
            // Continue execution even if upload fails
          }
        } else {
          console.log(
            "[trackShipmentsFromAIResult] Skipping SharePoint upload - environment variables not configured",
          );
        }
      } catch (excelError) {
        console.error(
          "[trackShipmentsFromAIResult] Failed to create Excel file",
          {
            error: excelError.message,
          },
        );
      }
    }

    // Calculate delivery summary
    const deliverySummary = {
      totalTracked: trackingResults.filter((r) => r.status === "success")
        .length,
      delivered: trackingResults.filter((r) => r.deliveryStatus === "delivered")
        .length,
      inTransit: trackingResults.filter(
        (r) => r.deliveryStatus === "in_transit",
      ).length,
      deliveredShipments: trackingResults
        .filter((r) => r.deliveryStatus === "delivered")
        .map((r) => ({
          trackingNumber: r.trackingNumber,
          carrier: r.carrier,
          deliveryDate: r.deliveryDate,
          deliveryLocation: r.deliveryLocation,
        })),
    };

    console.log(
      "[trackShipmentsFromAIResult] Delivery Summary:",
      deliverySummary,
    );

    return {
      success: true,
      totalItems: items.length,
      trackingResults: trackingResults,
      deliverySummary: deliverySummary,
      excelFilePath: excelFilePath,
      sharepointUrl: sharepointUploadResult?.webUrl || null,
      message: "Shipment tracking completed",
    };
  } catch (error) {
    const duration = Date.now() - startTime;
    console.error("[trackShipmentsFromAIResult] Error occurred", {
      error: error.message,
      stack: error.stack,
      duration: `${duration}ms`,
      timestamp: new Date().toISOString(),
    });

    return {
      success: false,
      error: error.message,
      message: "Failed to track shipments",
    };
  }
}

/**
 * Track shipment via DHL API
 * Uses direct HTTP call when API key available (local), destination-managed auth in BTP
 */
async function trackDHL(trackingNumber) {
  console.log("[trackDHL] Tracking shipment", { trackingNumber });

  try {
    const dhlApiKey = process.env.DHL_API_KEY;

    // Check if we have local API key (for development/testing)
    if (dhlApiKey && dhlApiKey !== "YOUR_DHL_API_KEY") {
      console.log("[trackDHL] Using direct HTTP call with API key");

      // Make direct HTTP call bypassing destination service
      const axios = require("axios");
      const dhlApiUrl =
        process.env.DHL_API_URL || "https://api-eu.dhl.com/track/shipments";

      const response = await axios.get(
        `${dhlApiUrl}?trackingNumber=${encodeURIComponent(trackingNumber)}`,
        {
          headers: {
            "DHL-API-Key": dhlApiKey,
            Accept: "application/json",
          },
          timeout: 30000,
        },
      );

      console.log("[trackDHL] Successfully retrieved tracking data", {
        trackingNumber,
        hasShipments: !!response.data.shipments,
      });

      return response.data;
    } else {
      console.log("[trackDHL] Using destination-managed authentication");

      // Use destination-managed authentication (BTP production)
      const dhlDestination = await cds.connect.to("DHL");
      const data = await dhlDestination.send({
        method: "GET",
        path: `?trackingNumber=${encodeURIComponent(trackingNumber)}`,
        headers: {
          "Content-Type": "application/json",
        },
      });

      console.log("[trackDHL] Successfully retrieved tracking data", {
        trackingNumber,
        hasShipments: !!data.shipments,
      });

      return data;
    }
  } catch (error) {
    console.error("[trackDHL] API error", {
      error: error.message,
      trackingNumber,
    });
    throw new Error(`DHL API error: ${error.message}`);
  }
}

/**
 * Track shipment via FedEx API
 * Uses manual OAuth when credentials available (local), destination-managed OAuth in BTP
 */
async function trackFedEx(trackingNumber) {
  console.log("[trackFedEx] Tracking shipment", { trackingNumber });

  try {
    // Connect to FedEx destination
    const fedexDestination = await cds.connect.to("FedEx");
    console.log("[trackFedEx] Connected to FedEx destination");

    const clientId = process.env.FEDEX_CLIENT_ID;
    const clientSecret = process.env.FEDEX_CLIENT_SECRET;

    // Check if we have local credentials (for development/testing)
    if (clientId && clientSecret && clientId !== "YOUR_FEDEX_CLIENT_ID") {
      console.log("[trackFedEx] Using manual OAuth with local credentials");

      // Step 1: Get OAuth token manually
      // Build form-urlencoded body as string (not JSON object)
      const formBody = `grant_type=client_credentials&client_id=${encodeURIComponent(clientId)}&client_secret=${encodeURIComponent(clientSecret)}`;

      const tokenData = await fedexDestination.send({
        method: "POST",
        path: "/oauth/token",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        data: formBody,
      });

      const accessToken = tokenData.access_token;
      console.log("[trackFedEx] OAuth token obtained manually");

      // Step 2: Track shipment with manual token
      const trackData = await fedexDestination.send({
        method: "POST",
        path: "/track/v1/trackingnumbers",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
          "X-locale": "en_US",
        },
        data: {
          includeDetailedScans: true,
          trackingInfo: [
            {
              trackingNumberInfo: {
                trackingNumber: trackingNumber,
              },
            },
          ],
        },
      });

      console.log(
        "[trackFedEx] Successfully retrieved tracking data (manual OAuth)",
        {
          trackingNumber,
          hasResults: !!trackData.output,
        },
      );

      return trackData;
    } else {
      // Use destination-managed OAuth (BTP with OAuth2ClientCredentials)
      // Destination automatically injects the Authorization header
      console.log("[trackFedEx] Using destination-managed OAuth");

      const trackData = await fedexDestination.send({
        method: "POST",
        path: "/track/v1/trackingnumbers",
        headers: {
          "Content-Type": "application/json",
          "X-locale": "en_US",
        },
        data: {
          includeDetailedScans: true,
          trackingInfo: [
            {
              trackingNumberInfo: {
                trackingNumber: trackingNumber,
              },
            },
          ],
        },
      });

      console.log(
        "[trackFedEx] Successfully retrieved tracking data (destination-managed OAuth)",
        {
          trackingNumber,
          hasResults: !!trackData.output,
        },
      );

      return trackData;
    }
  } catch (error) {
    console.error("[trackFedEx] API error", {
      error: error.message,
      trackingNumber,
    });
    throw new Error(`FedEx API error: ${error.message}`);
  }
}

/**
 * Helper function to retry database operations with exponential backoff
 * Handles SQLite "database is locked" errors
 */
async function retryDatabaseOperation(
  operation,
  maxRetries = 5,
  initialDelay = 200,
) {
  let lastError;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error;

      // Check if it's a database lock error
      const isLockError =
        error.message &&
        (error.message.toLowerCase().includes("database is locked") ||
          error.message.toLowerCase().includes("locked"));

      if (isLockError && attempt < maxRetries) {
        const delay = initialDelay * Math.pow(2, attempt - 1); // Exponential backoff: 200, 400, 800, 1600, 3200ms
        console.log(
          `⏳ Database locked, retrying in ${delay}ms (attempt ${attempt}/${maxRetries})...`,
        );
        await new Promise((resolve) => setTimeout(resolve, delay));
        continue;
      }

      // If it's not a lock error or we've exhausted retries, throw
      throw error;
    }
  }

  throw lastError;
}

// const { getAttachment } = require("./getMail");
module.exports = cds.service.impl(function () {
  console.log(
    "CatalogService implementation loaded - uploadFile handler registered",
  );

  // Register email service handlers
  emailService.call(this);

  // Register tracking service handlers
  trackingService.call(this);

  this.on("processFileFromSharePoint", async (req) => {
    console.log("processFileFromSharePoint handler triggered!");
    console.log("Loading environment variables.......");
    xsenv.loadEnv();

    const { fileName, siteUrl, libraryName, recipient, senderEmail } = req.data;
    console.log("Processing file from SharePoint:", fileName);
    console.log("Site URL:", siteUrl);
    console.log("Library:", libraryName);

    try {
      // Get file from SharePoint
      const fileBuffer = await sharepointService.getFileFromSharePoint(
        siteUrl,
        libraryName,
        fileName,
      );

      // Convert to base64
      const fileContent = fileBuffer.toString("base64");
      console.log(
        "File converted to base64, size:",
        fileBuffer.length,
        "bytes",
      );

      // Process with AI
      const result = await analyzePrompt(fileContent);

      // Send email if recipient is provided
      //   if (recipient && senderEmail) {
      //     console.log("Sending email to:", recipient);
      //     try {
      //       const htmlBody = outlookService.formatPODataAsHTML(result);
      //       const poNumber = result.header?.PONumber || "Unknown";
      //       const subject = `Purchase Order - ${poNumber}`;

      //       await outlookService.sendEmail(
      //         recipient,
      //         subject,
      //         htmlBody,
      //         senderEmail,
      //       );

      //       console.log("Email sent successfully to", recipient);
      //       result.emailSent = true;
      //       result.emailRecipient = recipient;
      //     } catch (emailError) {
      //       console.error("Email sending failed:", emailError.message);
      //       result.emailSent = false;
      //       result.emailError = emailError.message;
      //     }
      //   }

      // Trigger workflow to create MyInbox task
      console.log("Triggering workflow for MyInbox...");
      try {
        const workflowResult = await workflowService.createMyInboxTask(
          result,
          fileName,
          process.env.DEFAULT_WORKFLOW_ASSIGNEE,
        );

        result.workflowTriggered = workflowResult.success;
        if (workflowResult.success) {
          result.taskId = workflowResult.taskId;
          result.taskUrl = workflowResult.taskUrl;
          console.log("MyInbox task created:", workflowResult.taskId);
        } else {
          result.workflowError = workflowResult.error;
        }
      } catch (workflowError) {
        console.error("Workflow trigger failed:", workflowError.message);
        result.workflowTriggered = false;
        result.workflowError = workflowError.message;
      }

      return result;
    } catch (error) {
      console.error("Error processing SharePoint file:", error);
      return {
        error: error.message,
        fileName: fileName,
        source: "SharePoint",
      };
    }
  });

  this.on("listSharePointFiles", async (req) => {
    console.log("🚀 listSharePointFiles handler triggered!");
    xsenv.loadEnv();

    const { siteUrl, libraryName, folderPath } = req.data;
    console.log("Listing files from SharePoint");
    console.log("Site URL:", siteUrl);
    console.log("Library:", libraryName);
    console.log("Folder:", folderPath || "root");

    try {
      const files = await sharepointService.listFiles(
        siteUrl,
        libraryName,
        folderPath || "",
      );

      return JSON.stringify({
        success: true,
        count: files.length,
        files: files,
      });
    } catch (error) {
      console.error("Error listing SharePoint files:", error);
      return JSON.stringify({
        error: error.message,
        source: "SharePoint",
      });
    }
  });

  this.on("processFileFromFolder", async (req) => {
    console.log("🚀 processFileFromFolder handler triggered!");
    console.log("Loading environment variables.......");
    xsenv.loadEnv();

    const { fileName, recipient, senderEmail } = req.data;
    console.log("Processing file:", fileName);

    try {
      // Construct file path
      const filesDir = path.join(__dirname, "..", "files");
      const filePath = path.join(filesDir, fileName);

      console.log("Looking for file at:", filePath);

      // Check if file exists
      if (!fs.existsSync(filePath)) {
        throw new Error(
          `File not found: ${fileName}. Please place the file in the 'files' folder.`,
        );
      }

      // Read file and convert to base64
      const fileBuffer = fs.readFileSync(filePath);
      const fileContent = fileBuffer.toString("base64");

      console.log("File read successfully, size:", fileBuffer.length, "bytes");

      // Process with AI
      // const result = await analyzePrompt(fileContent);// GPT-4o-mini
      const result = await analyzePromptGPT5Nano(fileContent);

      // Send email if recipient is provided
      if (recipient && senderEmail) {
        console.log("Sending email to:", recipient);
        try {
          const htmlBody = outlookService.formatPODataAsHTML(result);
          const poNumber = result.header?.PONumber || "Unknown";
          const subject = `Purchase Order - ${poNumber}`;

          await outlookService.sendEmail(
            recipient,
            subject,
            htmlBody,
            senderEmail,
          );

          console.log("Email sent successfully to", recipient);
          result.emailSent = true;
          result.emailRecipient = recipient;
        } catch (emailError) {
          console.error("Email sending failed:", emailError.message);
          result.emailSent = false;
          result.emailError = emailError.message;
        }
      }

      // Trigger workflow to create MyInbox task
      console.log("Triggering workflow for MyInbox...");
      try {
        const workflowResult = await workflowService.createMyInboxTask(
          result,
          fileName,
          process.env.DEFAULT_WORKFLOW_ASSIGNEE,
        );

        result.workflowTriggered = workflowResult.success;
        if (workflowResult.success) {
          result.taskId = workflowResult.taskId;
          result.taskUrl = workflowResult.taskUrl;
          console.log("MyInbox task created:", workflowResult.taskId);
        } else {
          result.workflowError = workflowResult.error;
        }
      } catch (workflowError) {
        console.error("Workflow trigger failed:", workflowError.message);
        result.workflowTriggered = false;
        result.workflowError = workflowError.message;
      }

      return result;
    } catch (error) {
      console.error("Error processing file:", error);
      return {
        error: error.message,
        fileName: fileName,
      };
    }
  });

  this.on("uploadFile", async (req) => {
    console.log("🚀 uploadFile handler triggered!");
    console.log("Loading environment variables.......");
    xsenv.loadEnv();
    console.log("Request Data:", req.data);
    const { fileName, fileContent } = req.data;

    try {
      const result = await analyzePrompt(fileContent);

      return result;
    } catch (error) {
      return {
        sender: "AI",
        createdBy: "System",
        messageType: "Text",
        createdAt: new Date(),
        message: `Error processing request: ${error.message}`,
      };
    }
  });

  this.on("sendPOEmail", async (req) => {
    console.log("🚀 sendPOEmail handler triggered!");
    xsenv.loadEnv();

    const { recipient, senderEmail, poData } = req.data;
    console.log("Sending email to:", recipient);
    console.log("From:", senderEmail);

    try {
      // Parse PO data if it's a string
      const parsedData =
        typeof poData === "string" ? JSON.parse(poData) : poData;

      // Format data as HTML
      const htmlBody = outlookService.formatPODataAsHTML(parsedData);

      // Generate subject
      const poNumber = parsedData.header?.PONumber || "Unknown";
      const subject = `Purchase Order - ${poNumber}`;

      // Send email
      const result = await outlookService.sendEmail(
        recipient,
        subject,
        htmlBody,
        senderEmail,
      );

      return JSON.stringify({
        success: true,
        message: `Email sent successfully to ${recipient}`,
        poNumber: poNumber,
      });
    } catch (error) {
      console.error("Error sending email:", error);
      return JSON.stringify({
        success: false,
        error: error.message,
      });
    }
  });

  this.on("listUserEmails", async (req) => {
    console.log("listUserEmails handler triggered!");
    xsenv.loadEnv();

    const { userEmail, folderId = "inbox", maxMessages = 10 } = req.data;
    console.log("Listing emails for:", userEmail);

    try {
      const emails = await outlookService.listEmails(
        userEmail,
        folderId,
        maxMessages,
      );

      const emailList = emails.map((email) => ({
        id: email.id,
        subject: email.subject,
        from: email.from.emailAddress.address,
        receivedDateTime: email.receivedDateTime,
        hasAttachments: email.hasAttachments,
        bodyPreview: email.bodyPreview.substring(0, 100) + "...",
      }));

      return JSON.stringify({
        success: true,
        count: emailList.length,
        emails: emailList,
      });
    } catch (error) {
      console.error("Error listing emails:", error);
      return JSON.stringify({
        success: false,
        error: error.message,
      });
    }
  });

  this.on("processEmailWithAttachment", async (req) => {
    console.log("processEmailWithAttachment handler triggered!");
    xsenv.loadEnv();

    const { userEmail, emailId, recipient } = req.data;
    console.log("Processing email:", emailId);
    console.log("User:", userEmail);

    try {
      // Get email details
      const email = await outlookService.getEmailById(userEmail, emailId);
      console.log("Email subject:", email.subject);

      let extractedData = null;
      let sourceName = "";
      let extractionMethod = "";

      // Check for PDF or image attachments
      if (email.hasAttachments) {
        const attachments = await outlookService.getEmailAttachments(
          userEmail,
          emailId,
        );

        // Find PDF or image attachment
        const docAttachment = attachments.find(
          (att) =>
            att.contentType === "application/pdf" ||
            att.name.toLowerCase().endsWith(".pdf") ||
            att.contentType === "image/jpeg" ||
            att.contentType === "image/png" ||
            att.contentType === "image/tiff" ||
            att.name.toLowerCase().match(/\.(jpg|jpeg|png|tiff|tif)$/),
        );

        if (docAttachment) {
          console.log(
            "Found document attachment:",
            docAttachment.name,
            "Type:",
            docAttachment.contentType,
          );

          // Download attachment
          const fileData = await outlookService.downloadAttachment(
            userEmail,
            emailId,
            docAttachment.id,
          );

          // Convert to base64 for processing
          const fileContent = fileData.buffer.toString("base64");
          sourceName = fileData.name;

          // Use Document AI for extraction (supports PDF and images)
          console.log("Processing with SAP Document Information Extraction...");
          extractedData = await documentAIService.extractPurchaseOrder(
            fileContent,
            fileData.name,
          );
          extractionMethod = "SAP Document AI";
        }
      }

      // If no supported attachment found
      if (!extractedData) {
        throw new Error(
          "No PDF or image attachment found in email. Please attach a purchase order document (PDF, JPG, PNG, TIFF).",
        );
      }

      // Send notification email if recipient provided
      if (recipient && extractedData) {
        console.log("Sending extracted data to:", recipient);
        try {
          const htmlBody = outlookService.formatPODataAsHTML(extractedData);
          const poNumber = extractedData.header?.PONumber || "Unknown";
          const subject = `Extracted PO from Email - ${poNumber}`;

          await outlookService.sendEmail(
            recipient,
            subject,
            htmlBody,
            userEmail,
          );
        } catch (emailError) {
          console.error("Failed to send notification email:", emailError);
        }
      }

      // Trigger workflow
      let workflowResult = null;
      if (extractedData) {
        try {
          console.log("Triggering workflow for extracted PO data...");
          workflowResult = await workflowService.createMyInboxTask(
            extractedData,
            sourceName,
            userEmail,
          );
        } catch (workflowError) {
          console.error("Workflow trigger failed:", workflowError);
        }
        xtractionMethod: (extractionMethod, e);
      }

      return JSON.stringify({
        success: true,
        message: "Email processed successfully",
        source: sourceName,
        emailSubject: email.subject,
        extractedData: extractedData,
        emailSent: !!recipient,
        workflowTriggered: workflowResult?.success || false,
        taskId: workflowResult?.taskId,
        taskUrl: workflowResult?.taskUrl,
      });
    } catch (error) {
      console.error("Error processing email:", error);
      return JSON.stringify({
        success: false,
        error: error.message,
      });
    }
  });

  this.on("ReceiveNotification", async (req) => {
    xsenv.loadEnv();
    try {
      const fileData = await getAttachment();
      const fileContent = fileData.contentBytes;
      const fileName = fileData.fileName;
      const contentType = fileData.contentType;

      console.log(`Processing ${fileName} (${contentType})`);

      try {
        let oPOData;

        // Use Document AI for images, AI Core for PDFs
        // if (contentType?.startsWith("image/")) {
        //   console.log("Using SAP Document AI for image extraction...");
        //   oPOData = await documentAIService.extractPurchaseOrder(
        //     fileContent,
        //     fileName,
        //   );
        // } else {
        console.log("Using SAP AI Core for PDF/image extraction...");
        const result = await analyzeImagePrompt(fileContent);

        oPOData = typeof result === "string" ? JSON.parse(result) : result;

        // Track shipments automatically if DHL or FedEx found in items
        console.log("Checking for shipment tracking opportunities...");
        const trackingResult = await trackShipmentsFromAIResult(oPOData);

        if (
          trackingResult.success &&
          trackingResult.trackingResults.length > 0
        ) {
          console.log("Shipment tracking completed", {
            totalItems: trackingResult.totalItems,
            successCount: trackingResult.trackingResults.filter(
              (r) => r.status === "success",
            ).length,
            errorCount: trackingResult.trackingResults.filter(
              (r) => r.status === "error",
            ).length,
            deliverySummary: trackingResult.deliverySummary,
          });

          // Enrich oPOData with tracking information and delivery summary
          oPOData.trackingResults = trackingResult.trackingResults;
          oPOData.deliverySummary = trackingResult.deliverySummary;
          oPOData.excelFilePath = trackingResult.excelFilePath;
          oPOData.sharepointUrl = trackingResult.sharepointUrl;

          // Save tracking numbers to database for scheduled refresh
          try {
            const { ShipmentTracking } = cds.entities("sap.capire.salesorder");
            const poNumber = oPOData.header?.PONumber || "Unknown";

            for (const result of trackingResult.trackingResults) {
              if (result.status === "success") {
                // Use retry logic for database operations
                await retryDatabaseOperation(async () => {
                  // Check if record exists
                  const existing = await SELECT.one
                    .from(ShipmentTracking)
                    .where({ trackingNumber: result.trackingNumber });

                  if (existing) {
                    // Update existing record
                    await UPDATE(ShipmentTracking)
                      .set({
                        carrier: result.carrier,
                        deliveryStatus: result.deliveryStatus || "in_transit",
                        deliveryDate: result.deliveryDate,
                        deliveryLocation: result.deliveryLocation,
                        lastStatus:
                          result.deliveryStatus === "delivered"
                            ? "Delivered"
                            : "In Transit",
                        lastUpdatedAt: new Date().toISOString(),
                        isActive: result.deliveryStatus !== "delivered",
                      })
                      .where({ trackingNumber: result.trackingNumber });
                  } else {
                    // Insert new record
                    await INSERT.into(ShipmentTracking).entries({
                      trackingNumber: result.trackingNumber,
                      carrier: result.carrier,
                      deliveryStatus: result.deliveryStatus || "in_transit",
                      deliveryDate: result.deliveryDate,
                      deliveryLocation: result.deliveryLocation,
                      lastStatus:
                        result.deliveryStatus === "delivered"
                          ? "Delivered"
                          : "In Transit",
                      lastUpdatedAt: new Date().toISOString(),
                      isActive: result.deliveryStatus !== "delivered",
                      poNumber: poNumber,
                      description: result.item?.Description || "",
                    });
                  }
                });

                console.log(
                  `💾 Saved tracking number to database: ${result.trackingNumber}`,
                );
              }
            }
          } catch (dbError) {
            console.error(
              "Failed to save tracking numbers to database:",
              dbError,
            );
          }
        }
        // }

        // const dest = await cds.connect.to("TSP_RE");
        // const PODetails = oPOData;
        // const customerName = oPOData.header.DeliverTo.slice(0, 3);

        // function convertToSAPDateFormat(dateStr) {
        //   if (!dateStr) return null;
        //   const [month, day, year] = dateStr.split("/");
        //   const dateObj = new Date(`${year}-${month}-${day}T00:00:00Z`);
        //   return `/Date(${dateObj.getTime()})/`;
        // }

        // const payload = {
        //   CreationDate: convertToSAPDateFormat(PODetails?.header?.Date),
        //   SoldToParty: PODetails?.header?.DeliverTo ?? "",
        //   PurchaseOrderByShipToParty: PODetails?.header?.DeliverTo ?? "",
        //   TransactionCurrency: PODetails?.header?.Currency ?? "",
        //   SalesOrderDate: convertToSAPDateFormat(
        //     PODetails?.header?.DeliveryDate,
        //   ),
        //   TotalNetAmount: null,
        //   to_Item: {
        //     results: (PODetails?.items || []).map((item) => ({
        //       Material: "2345",
        //       RequestedQuantity: item?.OrderQuantity ?? "",
        //       RequestedQuantityUnit: "TON",
        //       SalesOrderItemText: item?.Description ?? "",
        //     })),
        //   },
        // };

        // const CustomerData = await dest.send({
        //   method: "GET",
        //   path: `/opu/odata/sap/C_CUSTOMER_OP_SRV/C_CustomerOP?$filter=substringof('${customerName}', CustomerName)&$expand=to_CustomerSalesArea`,
        // });

        // if (CustomerData.length > 0) {
        //   const customerRecord = CustomerData?.[0];
        //   const customerSalesDetails = customerRecord.to_CustomerSalesArea?.[0];
        //   payload.SalesOrderType = "OR";
        //   payload.SalesOrganization = customerSalesDetails.SalesOrganization;
        //   payload.DistributionChannel =
        //     customerSalesDetails.DistributionChannel;
        //   payload.OrganizationDivision = customerSalesDetails.Division;
        //   payload.SoldToParty = customerRecord.Customer;

        //   const items = payload.to_Item.results;
        //   if (items.length > 0) {
        //     for (let i = 0; i < items.length; i++) {
        //       const material = items[i];
        //       const materialData = await dest.send({
        //         method: "GET",
        //         path: `/opu/odata/sap/API_PRODUCT_SRV/A_ProductDescription?$filter=ProductDescription eq '${material.SalesOrderItemText}'`,
        //       });

        //       if (materialData.length > 0) {
        //         const selMaterial = materialData?.[materialData.length - 1];
        //         material.Material = selMaterial.Product;
        //       }
        //     }
        //   }

        //   const s4Response = await dest.send({
        //     method: "POST",
        //     path: "/opu/odata/sap/API_SALES_ORDER_SRV/A_SalesOrder",
        //     data: payload,
        //     headers: {
        //       "Content-Type": "application/json",
        //       Accept: "application/json",
        //     },
        //   });

        //   console.log("S/4 Response:", s4Response);
        //   return JSON.stringify({
        //     success: true,
        //     salesOrder: s4Response.SalesOrder,
        //     source: fileName,
        //     extractionMethod: contentType?.startsWith("image/")
        //       ? "SAP Document AI"
        //       : "SAP AI Core",
        //   });
        // }

        // req.error(
        //   500,
        //   `No Customer master Record found for ${payload.SoldToParty}`,
        // );

        return JSON.stringify(oPOData);
      } catch (error) {
        console.error("Processing error:", error);
        return JSON.stringify({
          success: false,
          error: error.message,
          message: `Error processing request: ${error.message}`,
        });
      }
    } catch (error) {
      console.error("Email retrieval error:", error);
      return JSON.stringify({
        success: false,
        error: error.message,
        message: "Error retrieving email",
      });
    }
  });

  // Scheduled refresh tracking action
  this.on("refreshTracking", async (req) => {
    console.log("🔄 [refreshTracking] Starting scheduled tracking refresh", {
      timestamp: new Date().toISOString(),
    });

    try {
      const { ShipmentTracking } = cds.entities("sap.capire.salesorder");

      // Query all active (non-delivered) shipments from database with retry
      const activeShipments = await retryDatabaseOperation(async () => {
        return await SELECT.from(ShipmentTracking).where({ isActive: true });
      });

      if (activeShipments.length === 0) {
        console.log("📭 [refreshTracking] No active shipments to track");
        return JSON.stringify({
          success: true,
          message: "No active shipments found",
          timestamp: new Date().toISOString(),
        });
      }

      console.log(
        `📦 [refreshTracking] Found ${activeShipments.length} active shipment(s) to refresh`,
      );

      const refreshResults = [];

      for (const shipment of activeShipments) {
        try {
          console.log(
            `[refreshTracking] Refreshing ${shipment.carrier} tracking: ${shipment.trackingNumber}`,
          );

          let trackingData;
          let deliveryStatus = "in_transit";
          let deliveryInfo = null;

          // Track based on carrier
          if (shipment.carrier === "DHL") {
            trackingData = await trackDHL(shipment.trackingNumber);

            if (trackingData.shipments && trackingData.shipments.length > 0) {
              const shipmentData = trackingData.shipments[0];
              if (shipmentData.events && Array.isArray(shipmentData.events)) {
                const deliveredEvent = shipmentData.events.find((event) =>
                  (event.description || "")
                    .toLowerCase()
                    .includes("shipment delivered"),
                );

                if (deliveredEvent) {
                  deliveryStatus = "delivered";
                  deliveryInfo = {
                    date: deliveredEvent.timestamp,
                    location:
                      deliveredEvent.location?.address?.addressLocality ||
                      "Unknown",
                  };
                }
              }
            }
          } else if (shipment.carrier === "FEDEX") {
            trackingData = await trackFedEx(shipment.trackingNumber);

            if (trackingData.output) {
              const trackResults =
                trackingData.output.completeTrackResults || [];
              if (
                trackResults.length > 0 &&
                trackResults[0].trackResults?.[0]?.scanEvents
              ) {
                const deliveredEvent =
                  trackResults[0].trackResults[0].scanEvents.find((event) =>
                    (event.eventDescription || "")
                      .toLowerCase()
                      .includes("delivered"),
                  );

                if (deliveredEvent) {
                  deliveryStatus = "delivered";
                  deliveryInfo = {
                    date: deliveredEvent.date,
                    location: deliveredEvent.scanLocation?.city || "Unknown",
                  };
                }
              }
            }
          }

          // Update database with new status using retry logic
          try {
            await retryDatabaseOperation(async () => {
              return await UPDATE(ShipmentTracking)
                .set({
                  deliveryStatus: deliveryStatus,
                  deliveryDate: deliveryInfo?.date,
                  deliveryLocation: deliveryInfo?.location,
                  lastStatus:
                    deliveryStatus === "delivered" ? "Delivered" : "In Transit",
                  lastUpdatedAt: new Date().toISOString(),
                  isActive: deliveryStatus !== "delivered",
                })
                .where({ trackingNumber: shipment.trackingNumber });
            });

            const statusEmoji = deliveryStatus === "delivered" ? "✅" : "📦";
            console.log(
              `${statusEmoji} [refreshTracking] ${shipment.trackingNumber}: ${deliveryStatus.toUpperCase()}`,
              deliveryInfo || {},
            );

            refreshResults.push({
              trackingNumber: shipment.trackingNumber,
              carrier: shipment.carrier,
              deliveryStatus,
              deliveryInfo,
              updated: true,
            });
          } catch (dbError) {
            // Database update failed after all retries
            const isLockError =
              dbError.message &&
              (dbError.message.toLowerCase().includes("database is locked") ||
                dbError.message.toLowerCase().includes("locked"));

            if (isLockError) {
              console.warn(
                `⚠️ [refreshTracking] Database still locked for ${shipment.trackingNumber}, will retry next cycle`,
              );
              refreshResults.push({
                trackingNumber: shipment.trackingNumber,
                carrier: shipment.carrier,
                deliveryStatus,
                deliveryInfo,
                updated: false,
                error: "Database locked - will retry next cycle",
              });
            } else {
              throw dbError; // Re-throw non-lock errors
            }
          }
        } catch (trackError) {
          console.error(
            `❌ [refreshTracking] Error tracking ${shipment.trackingNumber}:`,
            trackError.message,
          );
          refreshResults.push({
            trackingNumber: shipment.trackingNumber,
            carrier: shipment.carrier,
            error: trackError.message,
            updated: false,
          });
        }
      }

      const deliveredCount = refreshResults.filter(
        (r) => r.deliveryStatus === "delivered",
      ).length;
      const inTransitCount = refreshResults.filter(
        (r) => r.deliveryStatus === "in_transit",
      ).length;

      console.log("✅ [refreshTracking] Tracking refresh completed", {
        total: refreshResults.length,
        delivered: deliveredCount,
        inTransit: inTransitCount,
        errors: refreshResults.filter((r) => r.error).length,
      });

      return JSON.stringify({
        success: true,
        totalShipments: refreshResults.length,
        delivered: deliveredCount,
        inTransit: inTransitCount,
        results: refreshResults,
        timestamp: new Date().toISOString(),
        message: "Tracking refresh completed for all active shipments",
      });
    } catch (error) {
      console.error("❌ [refreshTracking] Error during tracking refresh:", {
        error: error.message,
        stack: error.stack,
      });

      return JSON.stringify({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      });
    }
  });
});
